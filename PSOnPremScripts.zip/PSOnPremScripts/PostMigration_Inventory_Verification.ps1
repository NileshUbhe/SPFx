<#
.SYNOPSIS
    This adds the Quicklaunch URLs if we have sub-sites
    Adds a Site Logo
    Tries to update Site Title
#>

function PostMigration-CleanUp {
    param (
        [Parameter(Mandatory = $true)][string]$TargetSiteUrl,
        [Parameter(Mandatory = $true)][string]$SiteTitle,
        [Parameter(Mandatory = $true)][string]$LogofilePath
    )
    
    try {
        if ($TargetSiteUrl) {
            $DestinationConnection = Connect-SP-Online-WithRetry -DestinationUrl $targetsiteurl -ClientId $ClientId -CertificatePath $CertificatePath -CertificatePwd $CertificatePwd -Tenant "marquardt.com"
            #Set Logo for site
            Set-PnPSite -LogoFilePath $LogofilePath -Connection $DestinationConnection
            Set-PnPWeb -Title $SiteTitle -SiteLogoUrl $LogofilePath -Connection $DestinationConnection
            $TargetOnlineSubweb = Get-PnPSubWeb -IncludeRootWeb -Connection $DestinationConnection -Recurse | Where-Object { $_.WebTemplate -ne "APP" }
            foreach ($TargetSubweb in $TargetOnlineSubweb) { 
                $logger.LogMessage("Post Migration cleanup Started for $($TargetSubweb.Url)")
                $subconnection = Connect-SP-Online-WithRetry -DestinationUrl $TargetSubweb.url -ClientId $ClientId -CertificatePath $CertificatePath -CertificatePwd $CertificatePwd -Tenant "marquardt.com"
                $subWeb = Get-PnPWeb -Connection $subconnection -Includes ParentWeb.ServerRelativeUrl -ErrorAction SilentlyContinue
                # Check for subsites and add them to Quick Launch
                if ($TargetSubweb.Url -ne $TargetSiteUrl) {
                    # Add a node at the first position in Quick Launch for the parent web
                    $parentQuickLaunchNode = @{
                        Title    = "Main Site URL"
                        Url      = $TenantUrl + $subWeb.ParentWeb.ServerRelativeUrl
                        Location = "QuickLaunch"
                        First    = $true
                    }
                    Add-PnPNavigationNode @parentQuickLaunchNode -Connection $subconnection -ErrorAction SilentlyContinue
                }
                $subsites = Get-PnPSubWeb -Connection $subconnection -Includes ParentWeb.ServerRelativeUrl
                if ($subsites.Count -gt 0) {
                    $quickLaunchHeading = @{
                        Title    = "SubSites"
                        Url      = ""
                        Location = "QuickLaunch"                        
                    }
                    Add-PnPNavigationNode @quickLaunchHeading -Connection $subconnection
                }
                foreach ($subsite in $subsites) {
                    $subwebprops = Get-PnPWeb -Connection $subconnection -Identity $subsite.Id -Includes ParentWeb.ServerRelativeUrl
                    $quickLaunchNode = @{
                        Title    = $subsite.Title
                        Url      = $subsite.Url
                        Location = "QuickLaunch"
                        Parent   = $quickLaunchHeading.Title
                    }
                    #Add quick launch to only immediate sub site.
                    if ($TargetSubweb.ServerRelativeUrl -eq $subwebprops.ParentWeb.ServerRelativeUrl) {
                        $parentNodes = Get-PnPNavigationNode -Location QuickLaunch -Connection $subconnection | Where-Object { $_.Title -eq "SubSites" }
                        $parentNode = $parentNodes | Select-Object -First 1
                        if ($parentNode) {
                            Add-PnPNavigationNode @quickLaunchNode -Parent $parentNode -Connection $subconnection
                        }
                        else {
                            Add-PnPNavigationNode @quickLaunchNode -Connection $subconnection
                        }
                    }
                }
                $logger.LogMessage("Post Migration cleanup completed for $($TargetSubweb.Url)")
            }
        }
    }
    catch {
        $logger.LogErrorMessage("PostMigration Validation - $($_.Exception.Message)")
    }
}

function Validate-Inventory($ExportFolderPath, $sourceRoomName, $targetsiteurl) {

    $allitemsCount = 0
    $allListsCount = 0    
    $allSPOSubSitesCount = 0
    $missingContentTypesFlag = $false
    $missingPermissionsFlag = $false
    try {
        $DestinationConnection = Connect-SP-Online-WithRetry -DestinationUrl $targetsiteurl -ClientId $ClientId -CertificatePath $CertificatePath -CertificatePwd $CertificatePwd -Tenant "marquardt.com"

        $TargetOnlineSubweb = Get-PnPSubWeb -IncludeRootWeb -Connection $DestinationConnection -Recurse | Where-Object { $_.WebTemplate -ne "APP" }
        $CheckRootWebSubSites = Get-PnPSubWeb -Connection $DestinationConnection -Recurse | Where-Object { $_.WebTemplate -ne "APP" }
        $allSPOSubSitesCount = $CheckRootWebSubSites.Count        
        foreach ($TargetSubweb in $TargetOnlineSubweb) { 
            $subconnection = Connect-SP-Online-WithRetry -DestinationUrl $TargetSubweb.url -ClientId $ClientId -CertificatePath $CertificatePath -CertificatePwd $CertificatePwd -Tenant "marquardt.com"
            $web = get-pnpweb -Connection $subconnection
            $siteRoomCheck = Get-PnPSite -Includes RootWeb -Connection $subconnection

            $subname = ""
            if ($web.ServerRelativeUrl.ToString().Length - $web.ServerrelativeUrl.ToString().IndexOf($sourceroomname) - $sourceroomname.ToString().Length -gt 0) {
                $subname = "_" + $web.Serverrelativeurl.ToString().Substring($web.ServerrelativeUrl.ToString().IndexOf($sourceroomname) + $sourceroomname.ToString().Length + 1)
            }
			
            if ($subname.contains("/")) {
                $subname = $subname.Replace("/", "_")
            }


            $exportfilename = "SiteItemInventory_$($sourceroomname)$($subname).csv"
            $SiteInventoryCSVPath = Join-Path -Path $ExportFolderPath -ChildPath $exportfilename


            if (-Not (Test-Path ($SiteInventoryCSVPath))) {
                $logger.LogMessage("Post Migration Inventory Report - No inventory reports generated for given source site $($SourceServerRelativeUrlce)")
            }
            else {
                $inventorydata = Import-Csv -Path $SiteInventoryCSVPath
            }

           

            $lists = Get-PnPList -Includes ItemCount -Connection $subconnection
            $faultedLists = 0
            $faultedItems = 0

            $totalLibraries = 0
            $totalLists = 0
            $totalItems = 0            
            foreach ($ListItemInventoryrow in $inventorydata) {                 
                
                # List item verification
                $logger.LogMessage("Post migration inventory report - check list $($ListItemInventoryrow.Title)")
            
                if ($ListItemInventoryrow.Object_Type -eq "List") {

                    try {
                        #$DestList = Get-PnPList -Includes ItemCount -Connection $DestinationConnection | Where-Object { $_.Title -eq $ListItemInventoryrow.Title } -ErrorAction SilentlyContinue
                        #$DestList = Get-PnPList -Includes ItemCount -Connection $DestinationConnection -Identity "Lists/$($ListItemInventoryrow.Title)" -ErrorAction SilentlyContinue
                        $destList = $lists | Where-Object { $_.Title -eq $ListItemInventoryrow.Title }
                    }
                    catch {
                        #$DestList = Get-PnPList -Includes ItemCount -Connection $DestinationConnection | Where-Object { $_.Title -eq $ListItemInventoryrow.Title } -ErrorAction SilentlyContinue
                        $DestList = $null # Get-PnPList -Includes ItemCount -Connection $DestinationConnection -Identity "Lists/$($ListItemInventoryrow.Title)" -ErrorAction SilentlyContinue
                    
                    }
                    if ($DestList) {
                        $ListItemInventoryrow.Destination_Count = $DestList.ItemCount
                        $totalLists++
                        $totalItems += $destList.ItemCount
                    }
                    else {
                        $ListItemInventoryrow.Destination_Count = -1
                        $faultedLists++
                    }
                    if ($ListItemInventoryrow.Destination_Count -lt $ListItemInventoryrow.Source_Count) {
                        $faultedItems += $ListItemInventoryrow.Source_Count - $ListItemInventoryrow.Destination_Count 
                    }
                    continue
                }

                if ($ListItemInventoryrow.Object_Type -eq "Library") {
                    if ($ListItemInventoryrow.Title -eq "Documents") {
                        $ListItemInventoryrow.Title = "Dokumente"
                    }
                   
                    try {
                        #$DestList = Get-PnPList -Includes ItemCount -Connection $DestinationConnection | Where-Object { $_.Title -eq $ListItemInventoryrow.Title } -ErrorAction SilentlyContinue
                        #$DestList = Get-PnPList -Includes ItemCount -Connection $DestinationConnection -Identity "Lists/$($ListItemInventoryrow.Title)" -ErrorAction SilentlyContinue
                        $destList = $lists | Where-Object { $_.Title -eq $ListItemInventoryrow.Title }
                    }
                    catch {
                        #$DestList = Get-PnPList -Includes ItemCount -Connection $DestinationConnection | Where-Object { $_.Title -eq $ListItemInventoryrow.Title } -ErrorAction SilentlyContinue
                        #$DestList = Get-PnPList -Includes ItemCount -Connection $DestinationConnection -Identity "Lists/$($ListItemInventoryrow.Title)" -ErrorAction SilentlyContinue
                        $destlist = $Null
                    }
                    if ($DestList) {
                        $ListItemInventoryrow.Destination_Count = $DestList.ItemCount
                        $totalLibraries++
                        $totalItems += $destList.ItemCount
                    }
                    else {
                        $ListItemInventoryrow.Destination_Count = 0
                        $faultedLists++
                    }
                    if ($ListItemInventoryrow.Destination_Count -lt $ListItemInventoryrow.Source_Count) {
                        $faultedItems += $ListItemInventoryrow.Source_Count - $ListItemInventoryrow.Destination_Count 
                    }
                    continue
                }

                # else
            }

            $entry = $inventorydata | Where-Object { $_.Title -eq "Total Libraries" }
            if ($entry) {
                $Entry.Destination_Count = $totalLibraries
            }

            $entry = $null
            $entry = $inventorydata | Where-Object { $_.Title -eq "Total Lists" }
            if ($entry) {
                $Entry.Destination_Count = $totalLists
            }
            if($web.ServerRelativeUrl -eq $siteRoomCheck.RootWeb.ServerRelativeUrl ) {
                $entry = $null
                $entry = $inventorydata | Where-Object { $_.Title -eq "Total Subsites" }
                if ($entry) {
                    $Entry.Destination_Count = $allSPOSubSitesCount
                }
            }

            <#
            $entry = $null
            $entry = $inventorydata | Where-Object {$_.Title -eq "System Content Type Count"}
            $SystemContentTypes = get-pnpcontentType -Connection $DestinationConnection | where-Object { $_.Group -notlike "_*" -and $_.Group -notlike "_Hidden*" -or $_.Group -notlike "MQ*" } | Select-Object -ExpandProperty Name
            if($entry) {
                
                $entry.Destination_Count = $SystemDestContentTypes.Count
            }

            $entry = $null
            $entry = $inventorydata | Where-Object {$_.Title -eq "System Content Type Names"}
            if($entry) {
                $SYSCTs = $SystemContentTypes -join ";"
                $entry.Destination_Count = $SYSCTs

                
                $SrcContentTypes = $inventorydata | Where-Object { $_.Title -eq "System Content Type Names" }| Select-Object -ExpandProperty Source_Count
                $sourceContentTypes = $SrcContentTypes -split ";"
                $destContentTypes = $SystemDestContentTypes -split ";"
                $missingContentTypes = $sourceContentTypes | Where-Object { $destContentTypes -notcontains $_ }
                $missingContentTypes = $sourceContentTypes | ForEach-Object {
                        $destContentTypes -contains $_
                    } | Where-Object { $_ -eq $false } | Measure-Object | Select-Object -ExpandProperty Count
                if($missingContentTypes.count -gt 0) {
                    $entry.Comment = "Missing content types - $($missingContentTypes -join ';')"
                }

            }

            $entry = $null
            $entry = $inventorydata | Where-Object {$_.Title -eq "Custom Content Type Count"}
            $MQCustomCTs = get-pnpcontentType -Connection $DestinationConnection | where-Object { $_.Group -like "_*" -and $_.Group -notlike "_Hidden*" -or $_.Group -like "MQ*" } | Select-Object -ExpandProperty Name
            if($entry) {
                
                $entry.Destination_Count = $MQCustomCTs.Count
            }

            $entry = $null
            $entry = $inventorydata | Where-Object {$_.Title -eq "Custom Content Type Names"}
            if($entry) {
                $CUSTCTs = $MQCustomCTs -join ";"
                $entry.Destination_Count = $CUSTCTs
            }
#>
            try {
                $entry = $null
                $entry = $inventorydata | Where-Object { $_.Title -eq "Source Permission Group Count" }
                $SourceGroups = Get-PnPGroup -Connection $DestinationConnection | Select-Object -ExpandProperty Title
                if ($entry) {
                    
                    $entry.Destination_Count = $SourceGroups.Count
                }
            
                $entry = $null
                $entry = $inventorydata | Where-Object { $_.Title -eq "Source Permission Group Names" }
                if ($entry) {
                    $CUSTGPs = $SourceGroups -join ";"
                    $entry.Destination_Count = $CUSTGPs
                }
            }
            catch {
                $logger.LogErrorMessage("Cannot retrieve Perssion group or group names")
            }
            try {
                $entry = $null
                $entry = $inventorydata | Where-Object { $_.Title -eq "Source Permission Level Count" }
                $SourcePermissionLevels = Get-PnPRoleDefinition -Connection $DestinationConnection | Select-Object -ExpandProperty Name
                if ($entry) {

                    $entry.Destination_Count = $SourcePermissionLevels.Count
                } 
                $entry = $null
                $entry = $inventorydata | Where-Object { $_.Title -eq "Source Permission Level Names" }
                
                if ($entry) {
                    $CUSTGPLs = $SourcePermissionLevels -join ";"
                    $entry.Destination_Count = $CUSTGPLs
                } 
            }
            catch {
                #$logger.LogErrorMessage("retrieve levels or level names")
            }
            $inventorydata | Export-Csv $SiteInventoryCSVPath

            $allitemsCount += $faultedItems
            $allListsCount += $faultedLists

        }
    }
    catch {
        $logger.LogErrorMessage("PostMigration Validation - $($_.Exception)")
        Write-Error $_.Exception.Message
    }

    $resultingdata = @{"FaultedLists" = $faultedLists; "FaultedItems" = $faultedItems; "TotalItems" = $totalItems }

    return , $resultingdata
}
<#

param (
    [Parameter(Mandatory = $true)][string]$SourceSiteUrl,
    [Parameter(Mandatory = $true)][string]$DestinationSiteURL,
    [Parameter(Mandatory = $true)][string]$ItemID
)


try {

    . "./PSOnPremScripts/MasterMigrationListFUnctions.ps1"  # loading MasterMigration Functions
    . "./PEPRooms/PEPMigration.ps1"  # loading Pep Room Migratin  Functions
    ."./STDRooms/STDMigration.ps1"  # loading Std Room Migratin  Functions
    #Attempt to connect to the SharePoint site
    #Connect site
    if (-not (Get-Module -ListAvailable -Name PnP.PowerShell)) {
        Import-Module PnP.PowerShell
    }     

    
    $sourceuri = [System.Uri]::new($SourceSiteUrl)
    $SourceServerRelativeUrl = $sourceuri.AbsolutePath
    #Read local configuration
    $scrdirpath= Split-Path $scriptDirectory -Parent
    Write-Host "Operation - Read Local config Started" -ForegroundColor Yellow
    $logger.LogMessage("Operation - Read Local config Started")
    $localconfigXmlPath = Join-Path -Path $scrdirpath -ChildPath "\Configuration\"
    $LocalXmlPath = Join-Path -Path $localconfigXmlPath -ChildPath "Local_Config.xml"
    # Check if the input folder exists
    if (-Not (Test-Path -Path $LocalXmlPath)) {
        $logger.LogErrorMessage("The local config file does not exist at: $LocalXmlPath")
        throw "The local config file does not exist at: $LocalXmlPath"
    }
    [xml]$LocalConfigXML = get-content $LocalXmlPath
    $ClientId = $LocalConfigXML.Configuration.Parameters.ClientId 
    $CertificatePath = $LocalConfigXML.Configuration.Parameters.CertificatePath
    $CertificatePwd = $LocalConfigXML.Configuration.Parameters.CertificatePwd 
    $LocalLogFolder = $LocalConfigXML.Configuration.Parameters.LocalLogFolder
    Write-Host "Operation - Read Local config completed" -ForegroundColor Green 
    $logger.LogMessage("Operation - Read Local config completed")
    $DestinationSiteItemInventory = @()
    $ExcludedLists = @();
    $RetryLists = @();

    $exclusionXmlFilePath = Join-Path -Path $scrdirpath -ChildPath "\Configuration\Excludedlists.xml"
    # Check if the exclusion XML file exists
    if (Test-Path -Path $exclusionXmlFilePath) {
        [xml]$exclusionlistXml = Get-Content -Path $exclusionXmlFilePath
        $ExcludedLists = $exclusionlistXml.Excludedlists.list
        $logger.LogMessage("Excluded List from migraion $($ExcludedLists)")
    }
    else {
        $logger.LogErrorMessage("No exclusion XML file found. Proceeding without exclusions.")
    }  
    
    Write-Progress -Activity "Started post migration inventory on $($SiteURL)" -Status "Started"
    $logger.LogMessage( "Started post migration inventory on $($SiteURL)") 
    # Verify siteinventory report for given source site.
    $Env_Prefix = Get-PrefixEnvironment -Environment $Environment
    $SourceServerRelativeUrl = $SourceServerRelativeUrl -replace $Env_Prefix
    $ExportFolderPath = Join-Path -Path $LocalLogFolder -ChildPath "$($SourceServerRelativeUrl)"
    $ExportItemInventoryReportPath = Join-Path -Path $ExportFolderPath -ChildPath "DestinationSiteItemInventory.csv"
    if (-Not (Test-Path -Path $ExportFolderPath)) {
        Write-Host "No inventory reports generated for given source site $($SourceServerRelativeUrlce)"
          $logger.LogMessage( "No inventory reports generated for given source site $($SourceServerRelativeUrlce)")
    }
    else {
        $SiteInventoryCSVPath = Join-Path -Path $ExportFolderPath -ChildPath "SiteItemInventory.csv"
        if (-Not (Test-Path ($SiteInventoryCSVPath))) {
            $logger.LogMessage("No inventory reports generated for given source site $($SourceServerRelativeUrlce)")
        }
        else {
            $SiteItemInventoryData = Import-Csv -Path $SiteInventoryCSVPath | Select-Object -Skip 1
            # Get destination list count
            $DestinationConnection = Connect-SP-Online-WithRetry -DestinationUrl $DestinationSiteURL -ClientId $ClientId -CertificatePath $CertificatePath -CertificatePwd $CertificatePwd -Tenant "marquardt.com"
            if ($DestinationConnection) {
            
                $ListItemInventoryData = $SiteItemInventoryData | Where-Object { $_.Object_Type -eq "List" }
                foreach ($ListItemInventoryrow in $ListItemInventoryData) {
                    # List item verification
                    $logger.LogMessage($ListItemInventoryrow.Title)
                   try {
                    $DestList = Get-PnPList -Includes ItemCount -Connection $DestinationConnection | Where-Object { $_.Title -eq $ListItemInventoryrow.Title } -ErrorAction SilentlyContinue
                
                   }
                   catch {
                    $DestList = Get-PnPList -Includes ItemCount -Connection $DestinationConnection | Where-Object { $_.Title -eq $ListItemInventoryrow.Title } -ErrorAction SilentlyContinue
                
                   }
                    $logger.LogMessage( $ListItemInventoryrow.Source_Count)
                    if ($DestList) {
                        $loopobj = New-Object System.Object
                        $loopobj | Add-Member -MemberType NoteProperty -Name "Title" -Value $ListItemInventoryrow.Title
                        $loopobj | Add-Member -MemberType NoteProperty -Name "Source_Count" -Value $ListItemInventoryrow.Source_Count
                        $loopobj | Add-Member -MemberType NoteProperty -Name "Destination_Count" -Value $DestList.ItemCount
                        $loopobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value ""
                        $DestinationSiteItemInventory += $loopobj    
                        #Retry copy operation for list
                        if ($ListItemInventoryrow.Source_Count -ne $DestList.ItemCount) {
                            # Retry copy list array # Mark as error in migration in master migration list.
                            $RetryLists += $ListItemInventoryrow.Title
                        }
                    }
                    else {
                        $loopobj = New-Object System.Object
                        $loopobj | Add-Member -MemberType NoteProperty -Name "Title" -Value $ListItemInventoryrow.Title
                        $loopobj | Add-Member -MemberType NoteProperty -Name "Source_Count" -Value $ListItemInventoryrow.Source_Count
                        $loopobj | Add-Member -MemberType NoteProperty -Name "Destination_Count" -Value "0"
                        $loopobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value "No List in destination with Title $($ListItemInventoryrow.Title)"
                        $DestinationSiteItemInventory += $loopobj    
                    }
                }
                #Content type inventory verification
                #$SysContentTypeInventoryData = $SiteItemInventoryData | Where-Object { $_.Object_Type -eq "System Content Type" }
                    
                #System content type verification
                $SystemDestContentTypes = get-pnpcontentType -Connection $DestinationConnection | where-Object { $_.Group -notlike "_*" -and $_.Group -notlike "_Hidden*" -or $_.Group -notlike "MQ*" } | Select-Object -ExpandProperty Name
                $SrcContentTypes = $SiteItemInventoryData | Where-Object { $_.Title -eq "System Content Type Names" }| Select-Object -ExpandProperty Source_Count
                $sourceContentTypes = $SrcContentTypes -split ";"
                $destContentTypes = $SystemDestContentTypes -split ";"
                $missingContentTypes = $sourceContentTypes | Where-Object { $destContentTypes -notcontains $_ }
                $missingContentTypes = $sourceContentTypes | ForEach-Object {
                         $destContentTypes -contains $_
                     } | Where-Object { $_ -eq $false } | Measure-Object | Select-Object -ExpandProperty Count
                    
                $loopobj = New-Object System.Object
                $loopobj | Add-Member -MemberType NoteProperty -Name "Title" -Value "System Content Type Count"
                $loopobj | Add-Member -MemberType NoteProperty -Name "Source_Count" -Value $sourceContentTypes.Count
                $loopobj | Add-Member -MemberType NoteProperty -Name "Destination_Count" -Value $destContentTypes.Count
                $loopobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value ""
                $DestinationSiteItemInventory += $loopobj 

                $loopobj = New-Object System.Object
                $loopobj | Add-Member -MemberType NoteProperty -Name "Title" -Value "System Content Type Names"
                $loopobj | Add-Member -MemberType NoteProperty -Name "Source_Count" -Value ($sourceContentTypes -join ";")
                $loopobj | Add-Member -MemberType NoteProperty -Name "Destination_Count" -Value ($destContentTypes -join ";")
                $loopobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value "Missing content types - $($missingContentTypes -join ';')"
                $DestinationSiteItemInventory += $loopobj 

                #Custom content type verification
                $MQCustomCTs = get-pnpcontentType -Connection $DestinationConnection | where-Object {$_.Group -like "_*" -and $_.Group -notlike "_Hidden*" -or $_.Group -like "MQ*"} | Select-Object -ExpandProperty Name
                $srcContentTypes = $SiteItemInventoryData | Where-Object { $_.Title -eq "Custom Content Type Names" }| Select-Object -ExpandProperty Source_Count 
                $sourceContentTypes = $SrcContentTypes -split ";"
                $destContentTypes = $MQCustomCTs -split ";"
                $missingContentTypes = $sourceContentTypes | Where-Object { $destContentTypes -notcontains $_ }
            
                $loopobj = New-Object System.Object
                $loopobj | Add-Member -MemberType NoteProperty -Name "Title" -Value "Custom Content Type Count"
                $loopobj | Add-Member -MemberType NoteProperty -Name "Source_Count" -Value $sourceContentTypes.Count
                $loopobj | Add-Member -MemberType NoteProperty -Name "Destination_Count" -Value $destContentTypes.Count
                $loopobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value ""
                $DestinationSiteItemInventory += $loopobj 

                $loopobj = New-Object System.Object
                $loopobj | Add-Member -MemberType NoteProperty -Name "Title" -Value "Custom Content Type Names"
                $loopobj | Add-Member -MemberType NoteProperty -Name "Source_Count" -Value ($sourceContentTypes -join ";")
                $loopobj | Add-Member -MemberType NoteProperty -Name "Destination_Count" -Value ($destContentTypes -join ";")
                $loopobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value "Missing content types - $($missingContentTypes -join ';')"
                $DestinationSiteItemInventory += $loopobj 

                #Sharepoint permission group verification
                $DestinationGroups = Get-PnPGroup -Connection $DestinationConnection | Select-Object -ExpandProperty Title
                $SrcPermissionGroups = $SiteItemInventoryData | Where-Object { $_.Title -eq "Source Permission Group Names" }| Select-Object -ExpandProperty Source_Count  
                $SourcePermissionGroups = $SrcPermissionGroups -split ";"
                $destPermissionGroups = $DestinationGroups -split ";"
                $missingPermisionGroups = $SourcePermissionGroups | Where-Object { $destPermissionGroups -notcontains $_ }
            
                $loopobj = New-Object System.Object
                $loopobj | Add-Member -MemberType NoteProperty -Name "Title" -Value "Sharepoint Groups Count"
                $loopobj | Add-Member -MemberType NoteProperty -Name "Source_Count" -Value $SourcePermissionGroups.Count
                $loopobj | Add-Member -MemberType NoteProperty -Name "Destination_Count" -Value $destPermissionGroups.Count
                $loopobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value ""
                $DestinationSiteItemInventory += $loopobj 

                $loopobj = New-Object System.Object
                $loopobj | Add-Member -MemberType NoteProperty -Name "Title" -Value "Sharepoint Groups Names"
                $loopobj | Add-Member -MemberType NoteProperty -Name "Source_Count" -Value ($SourcePermissionGroups -join ";")
                $loopobj | Add-Member -MemberType NoteProperty -Name "Destination_Count" -Value ($destPermissionGroups -join ";")
                $loopobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value "Missing Sharepoint Groups- $($missingPermisionGroups -join ';')"
                $DestinationSiteItemInventory += $loopobj 

                #Sharepoint permission level verification
                $DestinationPermissionLevels = Get-PnPRoleDefinition -Connection $DestinationConnection | Select-Object -ExpandProperty Name
                $SrcPermissionLevels = $SiteItemInventoryData | Where-Object { $_.Title -eq "Source Permission Level Names" }| Select-Object -ExpandProperty Source_Count 
                $SourcePermissionLevels = $SrcPermissionLevels -split ";"
                $DestPermissionLevels = $DestinationPermissionLevels -split ";"
                $MissingPermisionLevels = $SourcePermissionLevels | Where-Object { $DestPermissionLevels -notcontains $_ }
            
                $loopobj = New-Object System.Object
                $loopobj | Add-Member -MemberType NoteProperty -Name "Title" -Value "Sharepoint Permission Level Count"
                $loopobj | Add-Member -MemberType NoteProperty -Name "Source_Count" -Value $SourcePermissionLevels.Count
                $loopobj | Add-Member -MemberType NoteProperty -Name "Destination_Count" -Value $DestPermissionLevels.Count
                $loopobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value ""
                $DestinationSiteItemInventory += $loopobj 

                $loopobj = New-Object System.Object
                $loopobj | Add-Member -MemberType NoteProperty -Name "Title" -Value "Sharepoint Permission Level Names"
                $loopobj | Add-Member -MemberType NoteProperty -Name "Source_Count" -Value ($SourcePermissionLevels -join ";")
                $loopobj | Add-Member -MemberType NoteProperty -Name "Destination_Count" -Value ($DestPermissionLevels -join ";")
                $loopobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value "Missing Sharepoint Permission Levels $($MissingPermisionLevels -join ';')"
                $DestinationSiteItemInventory += $loopobj 
                
            }
            $DestinationConnection = $null
            $DestinationSiteItemInventory | Export-Csv -Path $ExportItemInventoryReportPath 
        }
    }
    if ($RetryLists.count -gt 0) {
        setStatus -SourceSiteURL $SourceSiteUrl -itemid $ItemID -status Errored -Credential $PNPMasterMigrationListConnection
        $nextstatus = 5
        $logger.LogErrorMessage( "Site migration status set for Errored Site for ID $($ItemID) in Master migration list")
    }
    setStatus -itemid $($item.ID) -status 3 -SourceSiteURL $SiteURL
    setCommunication -itemid $($item.ID) -status "Validation"  -SourceSiteURL $SiteURL
    setBanner -itemid $($item.ID) -status $true -SourceSiteURL $SiteURL
    $logger.LogMessage("Operation -  Premigration inventory completed.") 
}
catch {
    $logger.LogErrorMessage($_.Exception.Message)
}

#>