#Testing for corrupted list
$TargetSubwebs = Get-PnPSubWeb -Connection $PNP_SPO_PEP_Connection -IncludeRootWeb
$ListTitle = "Problem Reports"
foreach ($TargetSubweb in $TargetSubwebs) {
    $PNP_SPO_PEP_Sub_Connection = Connect-SP-Online-WithRetry -DestinationUrl $TargetSubweb.Url -ClientId $ClientId -CertificatePath $CertificatePath -CertificatePwd $CertificatePwd -Tenant "marquardt.com"
    if ($PNP_SPO_PEP_Sub_Connection) {
        #Remove Existing open issue list.
        $OpenIssue = Get-PnPList -Connection $PNP_SPO_PEP_Sub_Connection | Where-Object {$_.Title -eq $ListTitle} 
        if ($OpenIssue)
        {
        Remove-PnPList -Identity $ListTitle -Connection $PNP_SPO_PEP_Sub_Connection
        }
        #Create Open issue list [Task List] manually
        # Create Open Issues list
        
        $listTemplate = [Microsoft.SharePoint.Client.ListTemplateType]::Tasks
        $openIssuesList = New-PnPList -Title $ListTitle -Template $listTemplate -Url "Lists/PEP PR" -Connection $PNP_SPO_PEP_Sub_Connection
        # Add "PEP Open Issue" content type to the list
        $contentType = Get-PnPContentType -Identity "PEP PR" -Connection $PNP_SPO_PEP_Sub_Connection 
        if ($contentType)
        {
        Add-PnPContentTypeToList -List $openIssuesList -ContentType $contentType -Connection $PNP_SPO_PEP_Sub_Connection
        # Make "PEP Open Issue" the default content type
        Set-PnPDefaultContentTypeToList -List $ListTitle -ContentType "PEP PR" -Connection $PNP_SPO_PEP_Sub_Connection
        # Set list experience to modern
        Set-PnPList -Identity $openIssuesList -ListExperience NewExperience -ErrorAction SilentlyContinue -Connection $PNP_SPO_PEP_Sub_Connection
        }
    }

}

$TargetSubwebs = Get-PnPSubWeb -Connection $PNP_SPO_PEP_Connection -IncludeRootWeb
$ListTitle = "Open Issues"
foreach ($TargetSubweb in $TargetSubwebs) {
    $PNP_SPO_PEP_Sub_Connection = Connect-SP-Online-WithRetry -DestinationUrl $TargetSubweb.Url -ClientId $ClientId -CertificatePath $CertificatePath -CertificatePwd $CertificatePwd -Tenant "marquardt.com"
    if ($PNP_SPO_PEP_Sub_Connection) {
        #Remove Existing open issue list.
        $OpenIssue = Get-PnPList -Connection $PNP_SPO_PEP_Sub_Connection | Where-Object {$_.Title -eq $ListTitle} 
        if ($OpenIssue)
        {
        Remove-PnPList -Identity $ListTitle -Connection $PNP_SPO_PEP_Sub_Connection
        }
        #Create Open issue list [Task List] manually
        # Create Open Issues list
        
        $listTemplate = [Microsoft.SharePoint.Client.ListTemplateType]::Tasks
        $openIssuesList = New-PnPList -Title $ListTitle -Template $listTemplate -Url "Lists/OpenIssues" -Connection $PNP_SPO_PEP_Sub_Connection
        # Add "PEP Open Issue" content type to the list
        $contentType = Get-PnPContentType -Identity "PEP Open Issue" -Connection $PNP_SPO_PEP_Sub_Connection 
        if ($contentType)
        {
        Add-PnPContentTypeToList -List $openIssuesList -ContentType $contentType -Connection $PNP_SPO_PEP_Sub_Connection
        # Make "PEP Open Issue" the default content type
        Set-PnPDefaultContentTypeToList -List $ListTitle -ContentType "PEP Open Issue" -Connection $PNP_SPO_PEP_Sub_Connection
        # Set list experience to modern
        Set-PnPList -Identity $openIssuesList -ListExperience NewExperience -ErrorAction SilentlyContinue -Connection $PNP_SPO_PEP_Sub_Connection
        }
    }

}