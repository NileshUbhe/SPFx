<#
.SYNOPSIS
    [Provide a brief description of what the script or function does.]
#>
param (
    [Parameter(Mandatory = $true)][string]$SiteURL,
    [Parameter(Mandatory = $true)][PSCredential]$Credential,
    [Parameter(Mandatory = $false)][string[]]$ExcludedLists
)
try {
    #Attempt to connect to the SharePoint site
    #Connect site

    if (-not (Get-Module -ListAvailable -Name PnP.PowerShell)) {
        Import-Module PnP.PowerShell
    }   
    Write-Progress -Activity "Started check in on $($SiteURL)" -Status "Started" 
    $logger.LogMessage("Started check in on $($SiteURL)")
    $TargetOnPremSubweb = Get-PnPSubWeb -IncludeRootWeb -Connection $Onprem_Connection -Recurse | Where-Object { $_.WebTemplate -ne "APP" }

    foreach ($TargetSubweb in $TargetOnPremSubweb) {    

        $Onprem_Sub_Connection = Connect-SP-Onpremise-WithRetry -SiteURL $TargetSubweb.Url -Cred $Cred -maxRetries 3
        $ctx = Get-PnPContext -Connection $Onprem_Sub_Connection
        #Get all document libraries
        $DocumentLibraries = Get-PnPList -Connection $Onprem_Sub_Connection | Where-Object { $_.BaseType -eq "DocumentLibrary" -and $_.Hidden -eq $False }
        Write-Progress -Activity "Pre Migration check in" -Status "Started"
        #Iterate through document libraries
        ForEach ($List in $DocumentLibraries) {
            if ($ExcludedLists -contains $List.Title) {
                $logger.LogMessage("Skipping $($List.Title) as it is in the excluded lists.")
                continue
            }
            if ($list.Title -eq "Site Assets"){
                $logger.LogMessage("Skipping $($List.Title) since the OneNote files cannot be checked out")
                continue
            }
            #TakeOver CheckOut for each files have no check in version
            #$list = Get-PnPList -Identity "Lists/$listname"
            #changes due to pnp version 2.4
            #$ListTitle = $List.Title
            #$List_Instance = Get-PnPList -Identity "Lists/$ListTitle" 

            #$checkedOutFileCollection = $List_Instance.GetItems([Microsoft.SharePoint.Client.CamlQuery]::CreateAllItemsQuery())
            #$ctx.Load($checkedOutFileCollection)
            #$ctx.ExecuteQuery()
            #$checkedOutFileCollection = $checkedOutFileCollection | Where-Object { $_.FileSystemObjectType -eq "File" -and $_.CheckOutType -ne "None" }

            Write-Progress -Activity "Started check in on $($List.Title)" -Status "Started" 
            #$currentList = $Ctx.Web.lists.GetByTitle($List.Title)
            $checkedOutFileCollection = $List.GetCheckedOutFiles()
            $ctx.Load($checkedOutFileCollection)
            $ctx.Load($List.Fields)
            try {
                $ctx.ExecuteQuery()
            }
            catch {
                $logger.LogErrorMessage($_.Exception.Message)
                $logger.LogMessage("Skping author")
                continue
            }
            $logger.LogMessage("Found $($checkedOutFileCollection.Count) files without checkin version in $($List.Title) Library")
            $CheckpathCollection = @()
            ForEach ($chkotdfile in $checkedOutFileCollection) {
                $CheckedOutByUser = $chkotdfile.CheckedOutBy
                $ctx.Load($CheckedOutByUser)
                $chkotdfile.TakeOverCheckOut()
                $ctx.ExecuteQuery()
                $logger.LogMessage("File $($chkotdfile.ServerRelativePath.DecodedUrl) checked out by $($CheckedOutByUser.LoginName) has been takeover for checkout")
            }
            #Check in All Checked out Files of the library
            if ($List.ItemCount -eq 0) {
                $logger.LogMessage("Skipping $($List.Title) as it has no items.")
                continue
            }
            $checkedOutFileCollection = Get-PnPListItem -List $List -Connection $Onprem_Sub_Connection -Fields File, CheckoutUser -PageSize 500 -ScriptBlock { Param($items) $items.Context.ExecuteQuery() } | Where { $_["CheckoutUser"] -ne $Null } | Select-Object Id, File 
            ForEach ($chkotdfile in $checkedOutFileCollection) { 
                #Load file object
                $ctx.Load($chkotdfile.File)  
                $ctx.Load($chkotdfile.File.Versions)  
                $ctx.Load($chkotdfile.File.CheckedOutByUser)
                $ctx.ExecuteQuery()
                if ($chkotdfile.File.ServerRelativeUrl) {
                    #Check in all checkout documents.
                    Set-PnPFileCheckedIn -Url $chkotdfile.File.ServerRelativeUrl -Connection $Onprem_Sub_Connection -CheckinType MajorCheckIn -Comment "Checked in By Admin" -ErrorAction Stop 
                    $logger.LogMessage("File $($chkotdfile.File.ServerRelativeUrl) having $($chkotdfile.File.MinorVersion) been checked in")
                    $checkinobj = New-Object System.Object
                    $checkinobj | Add-Member -MemberType NoteProperty -Name "File Url" -Value $chkotdfile.File.ServerRelativeUrl
                    $checkinobj | Add-Member -MemberType NoteProperty -Name "Action" -Value "Check in by Admin"
                    $CheckpathCollection += $checkinobj
                    #Adding Query results to table object
                    #If document is checkin by Admin user and having single minor version - Delete
                    if ($chkotdfile.File.MinorVersion -eq 1 -and $chkotdfile.File.MajorVersion -eq 0 -and $chkotdfile.File.CheckedOutByUser.Title -eq $username ) {
                        Remove-PnPFile -ServerRelativeUrl $chkotdfile.File.ServerRelativeUrl -Connection $Onprem_Sub_Connection -Force -ErrorAction Stop
                        $logger.LogMessage( "File $($chkotdfile.File.ServerRelativeUrl) having $($chkotdfile.File.MinorVersion) been deleted")
                        $delobj = New-Object System.Object
                        $delobj | Add-Member -MemberType NoteProperty -Name "File Url" -Value $chkotdfile.File.ServerRelativeUrl
                        $delobj | Add-Member -MemberType NoteProperty -Name "Action" -Value "Deleted by Admin"
                        $CheckpathCollection += $delobj
                    }
                }
            }
        }
        # Disposing connection
        $Onprem_Sub_Connection = $null
    }
    $logger.LogMessage("Completed check in")
        
}
catch {
    $logger.LogErrorMessage($_.Exception.Message)
}