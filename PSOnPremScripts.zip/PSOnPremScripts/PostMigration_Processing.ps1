<#
.SYNOPSIS
   Script will be executed to perform various tasks after data migration is done by sharegate for site.
   1. Register subscription
   2. Update subscription
   3. Add app on pages
   4. etc...
#>
param (
    [Parameter(Mandatory = $false)][string]$DestinationSiteURL 
)

try {
    . "./PSOnPremScripts/MasterMigrationListFUnctions.ps1"  # loading MasterMigration Functions
    . "./PEPRooms/PEPMigration.ps1"  # loading Pep Room Migratin  Functions
    . "./STDRooms/STDMigration.ps1"  # loading Std Room Migratin  Functions

    #Attempt to connect to the SharePoint site
    #Connect site
    if (-not (Get-Module -ListAvailable -Name PnP.PowerShell)) {
        Import-Module PnP.PowerShell
    }  
    
    #Read local configuration
    #Define root directory
    $scriptDirectory = Split-Path -Path $MyInvocation.MyCommand.Definition -Parent
    $scrdirpath = Split-Path -Parent $scriptDirectory
    $logger.LogMessage("Operation - Read Local config Started")
    #$logger.LogMessage("Operation - Read Local config Started")
    $localconfigXmlPath = Join-Path -Path $scrdirpath -ChildPath "\Configuration\"
    $LocalXmlPath = Join-Path -Path $localconfigXmlPath -ChildPath "Local_Config.xml"
    # Check if the input folder exists
    if (-Not (Test-Path -Path $LocalXmlPath)) {
        $logger.LogErrorMessage("The local config file does not exist at: $LocalXmlPath")
        throw "The local config file does not exist at: $LocalXmlPath"
    }
    [xml]$LocalConfigXML = get-content $LocalXmlPath
    $ClientId = $LocalConfigXML.Configuration.Parameters.ClientId 
    $CertificatePath = $LocalConfigXML.Configuration.Parameters.CertificatePath
    $CertificatePwd = $LocalConfigXML.Configuration.Parameters.CertificatePwd 
    $PNP_SPO_PEP_Connection = Connect-SP-Online-WithRetry -DestinationUrl $DestinationSiteURL -ClientId $ClientId -CertificatePath $CertificatePath -CertificatePwd $CertificatePwd -Tenant "marquardt.com"
   
    #Set primary theme to office 
    <#
    $ColorPaletteUrl = "/_catalogs/theme/15/palette002.spcolor"
    $FontSchemeUrl = "/_catalogs/theme/15/SharePointPersonality.spfont"
    $BackgroundImageUrl = Out-Null
    Set-PnPTheme -ColorPaletteUrl $ColorPaletteUrl -BackgroundImageUrl  $BackgroundImageUrl -FontSchemeUrl $FontSchemeUrl -Connection $PNP_SPO_PEP_Connection
    #>
    # Update Navigation Tile list document item with updated link.
    $NavList = Get-PnPList -Identity "Navigation Tiles" -Connection $PNP_SPO_PEP_Connection -ErrorAction SilentlyContinue
    if ($NavList) {
        $DocItem = Get-PnPListItem -List $NavList -Connection $PNP_SPO_PEP_Connection -Query "<View><Query><Where><Eq><FieldRef Name='Title'/><Value Type='Text'>Documents</Value></Eq></Where></Query></View>"
        if ($DocItem) {
            $docLib = Get-PnPList -Identity "Dokumente" -Connection $PNP_SPO_PEP_Connection -ErrorAction SilentlyContinue
            $url = "https://marquardt.sharepoint.com" + $docLib.RootFolder.ServerRelativeUrl
            Set-PnPListItem -List "Navigation Tiles" -Identity $DocItem.Id -Values  @{"Link" = $url } -Connection $PNP_SPO_PEP_Connection
            $logger.LogMessage("Navigation tile item has been updated.")
        }
        #Update Links due to Pages moved to SitePages
        foreach ($item in $items) {
            $url = $item["Link"].Url
            if ($url.Contains("Lists"))
            {
                Set-PnPListItem -List "Navigation Tiles" -Identity $item.Id Values @{"Link" = $item['Link'].Url.Replace("Pages","SitePages"),$item['Link'].Description} -Connection $PNP_SPO_PEP_Connection
            }
        }
    }

    $LocalPPConfigXmlPath = Join-Path -Path $localconfigXmlPath -ChildPath "PostProcessing_Config.xml"
    # Check if the input folder exists
    if (-Not (Test-Path -Path $LocalPPConfigXmlPath)) {
        $logger.LogErrorMessage("PostProcessing config file does not exist at: $LocalPPConfigXmlPath")
        throw "PostProcessing config file does not exist at: $LocalPPConfigXmlPath"
    }
    [xml]$PostProcessingConfigXML = get-content $LocalPPConfigXmlPath
   
    #Register a subscription on given lists with given subscription URL.
    <# 
    $WebhookSubscriptions = $PostProcessingConfigXML.Configuration.Parameters.WebhookSubscriptions.WebhookSubscription
    foreach ($WebhookSubscription in $WebhookSubscriptions) {
        $expirationDate = (Get-Date).AddDays(179).ToString("yyyy-MM-dd")
        $ClientState = $WebhookSubscription.List
        $TargetList = Get-PnPList -Connection $PNP_SPO_PEP_Connection | Where-Object { $_.Title -eq $WebhookSubscription.List } 
        if ($TargetList) {
            Add-PnPWebhookSubscription -List $WebhookSubscription.List -NotificationUrl $WebhookSubscription.NotificationUrl -ExpirationDate  $expirationDate -ClientState $ClientState -Connection $PNP_SPO_PEP_Connection
            $logger.LogMessage(" webhook subscription is registered on $($WebhookSubscription.List) List.")
        }
        else {
            $logger.LogMessage("$($WebhookSubscription.List) List does not exist for webhook subscription")
        }
    }
    #>

    $CustomApps = $PostProcessingConfigXML.Configuration.Parameters.Apps.App
    #Add an App on given site with given app id.
    foreach ($CustomApp in $CustomApps) {
        $MqApp = Get-PnPApp -Identity $CustomApp.App_id -Scope Tenant -Connection $PNP_SPO_PEP_Connection
        if ($null -eq $MqApp.InstalledVersion ) {
            Install-PnPApp -Identity $CustomApp.App_id -Scope Tenant -Connection $PNP_SPO_PEP_Connection
            $logger.LogMessage("$($CustomApp.App_id) is added to $($DestinationSiteURL).")
        }
        else {
            $logger.LogMessage("App is already installed on the site $($DestinationSiteURL)")
        }
    }

    #Register form Customizer for PEP PR
    $newFormId = "0a157867-964c-4c4c-a47a-691d3dbb65f9"
    $editFormId = "0a157867-964c-4c4c-a47a-691d3dbb65f9"
    $displayFormId = "0a157867-964c-4c4c-a47a-691d3dbb65f9"
    Set-PnPContentType -List "Problem Reports" -Identity "PEP PR" -ReadOnly $false -Conneue -Connection $PNP_SPO_PEP_Connection
    Set-PnPContentType -List "Problem Reports" -Identity "PEP PR" -NewFormClienue -ConnetSideComponentId $newFormId -EditFormClientSideComponentId $editFormId -DisplayFormClientSideComponentId $displayFormId -Connection $PNP_SPO_PEP_Connection
    Set-PnPContentType -List "Problem Reports" -Identity "PEP PR" -ReadOnly $true -Conneue -Connection $PNP_SPO_PEP_Connection
    #Provision pages with webpart
    $SlashCount = 0
    if (-not [string]::IsNullOrEmpty($DestinationSiteURL)) {
        $SlashCount = ($DestinationSiteURL -split '/').Count
    }
    if ($SlashCount -eq 5) {
        #Site is root level
        $TemplateXmlPath = Join-Path -Path $scrdirpath -ChildPath "\Templates\PEP\"
        $PageXmlTemplatePath = Join-Path -Path $TemplateXmlPath -ChildPath "Root.xml"
    }
    else {
        $TemplateXmlPath = Join-Path -Path $scrdirpath -ChildPath "\Templates\PEP\"
        $PageXmlTemplatePath = Join-Path -Path $TemplateXmlPath -ChildPath "Subroom.xml"
    }
    Invoke-PnPSiteTemplate -Path $PageXmlTemplatePath -Connection $PNP_SPO_PEP_Connection
    $logger.LogMessage("Page template has been applied to $($DestinationSiteURL)")
    Set-PnPHomePage -RootFolderRelativeUrl SitePages/Start.aspx -Connection $PNP_SPO_PEP_Connection   
    $logger.LogMessage("Page Start.aspx has been set as Homepage to $($DestinationSiteURL)")
}
catch {
    $logger.LogErrorMessage($_.Exception.Message)
}