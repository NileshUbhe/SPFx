<#
.SYNOPSIS
    [Provide a brief description of what the script or function does.]
#>
<# param (
    [Parameter(Mandatory = $true)][string]$SiteURL,
    [Parameter(Mandatory = $true)][PSCredential]$Credential,
    [Parameter(Mandatory = $false)][string[]]$ExcludedLists
)
 #>


function Create-InventoryReport($sourceroomname, $connection, $logdir, $ExcludedLists) {

    try {
        $logger.LogMessage("Started pre migration inventory on $($SiteURL)")
        $TargetOnPremSubweb = Get-PnPSubWeb -IncludeRootWeb -Connection $connection -Recurse | Where-Object { $_.WebTemplate -ne "APP" }

        foreach ($TargetSubweb in $TargetOnPremSubweb) 
        {    
            $script:DiscussionWeb = $false
            if($TargetSubweb.WebTemplate -eq "BLOG") {                 
                $logger.LogWarningMessage("This is a BLOG SubSite and therefore it will be skipped from Inventory Report")
                continue
            }

            $Onprem_Sub_Connection = Connect-SP-Onpremise-WithRetry -SiteURL $TargetSubweb.Url -Cred $Cred -maxRetries 3            
            $web = Get-PnPWeb -Connection $Onprem_Sub_Connection
            $SiteItemInventory = @()
            
            $libraries = Get-PnPList -Connection $Onprem_Sub_Connection -Includes ItemCount, BaseTemplate            
            $siteRoomCheck = Get-PnPSite -Includes RootWeb -Connection $Onprem_Sub_Connection
            $totallists = 0
            $totalLibraries = 0
            
            #$DocumentLibraries = Get-PnPList -Connection $Onprem_Sub_Connection | Where-Object { $_.BaseType -eq "DocumentLibrary" -and $_.Hidden -eq $False -and $ExcludedLists -notcontains $_.Title } 
            ForEach ($List in $libraries) {
                if ($ExcludedLists -contains $List.Title) {
                    $logger.LogMessage("Skipping $($List.Title) as it is in the excluded lists.")
                    continue
                } 
                if($List.Hidden -eq $true) {
                    Write-Host "Skipping $($List.Title) due to hiddeness"
                    continue
                }
                if($List.BaseTemplate -eq 108) {
                    Write-Host "Skipping $($List.Title) since it is of type Discussion Board"
                    $script:DiscussionWeb = $true
                    continue
                }
                if($List.BaseTemplate -eq 106) {
                    Write-Host "Skipping $($List.Title) since it is of type Calendar"
                    continue
                }
                
                if($List.BaseTemplate -eq 102) {
                    Write-Host "Skipping $($List.Title) since it is of type Survey"
                    continue
                }

                #$FileItems = Get-PnPListItem -List $List -PageSize 500 -Fields FileLeafRef -Connection $Onprem_Sub_Connection | Where-Object { $_.FileSystemObjectType -eq "File" }
                $loopobj = New-Object System.Object
                $loopobj | Add-Member -MemberType NoteProperty -Name "Title" -Value $List.Title
                $loopobj | Add-Member -MemberType NoteProperty -Name "Source_Count" -Value $list.ItemCount
                $loopobj | Add-Member -MemberType NoteProperty -Name "Destination_Count" -Value 0
                $valid = $false
                if($list.BaseType -eq "DocumentLibrary") {
                    $loopobj | Add-Member -MemberType NoteProperty -Name "Object_Type" -Value "Library"    
                    $totalLibraries++
                    $valid = $true
                }
                if($list.BaseType -eq "GenericList") {
                    $loopobj | Add-Member -MemberType NoteProperty -Name "Object_Type" -Value "List"
                    $totallists++
                    $valid = $true
                }
                #$loopobj | Add-Member -MemberType NoteProperty -Name "Object_Type" -Value "Library"
                 $loopobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value ""
                 if($valid -eq $true) {
                    $SiteItemInventory += $loopobj
                 }                
            }

            #Discussion sub-site skip and read all the SubSites
            if($web.ServerRelativeUrl -eq $siteRoomCheck.RootWeb.ServerRelativeUrl ) {
                Write-Host "Main Room will be checked for Discussion Lists"
                $checkRootWebSubSites = Get-PnPSubWeb -Connection $connection -Recurse | Where-Object { $_.WebTemplate -ne "APP" }
                $totalSubSites = $checkRootWebSubSites.Count
                #Get total count of Document libraries on source                
                $loopobj = New-Object System.Object
                $loopobj | Add-Member -MemberType NoteProperty -Name "Title" -Value "Total Subsites"
                $loopobj | Add-Member -MemberType NoteProperty -Name "Source_Count" -Value $totalSubSites
                $loopobj | Add-Member -MemberType NoteProperty -Name "Destination_Count" -Value 0
                $loopobj | Add-Member -MemberType NoteProperty -Name "Object_Type" -Value "Subsites Count"
                $loopobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value ""
                $SiteItemInventory += $loopobj
            }
            else              
            {
                if($script:DiscussionWeb -eq $true)
                {
                  Write-Host "$($TargetSubweb.Url) is skipped because it is a Discussion List"
                  continue                   
                }                
            }

            #Get total Number of Documents         
            #$loopobj | Add-Member -MemberType NoteProperty -Name "Number of Documents" -Value $global:counter
    
            #Get Number of Items
            <#
            try {
                $Lists = Get-PnPList -Connection $Onprem_Sub_Connection | Where-Object { $_.BaseType -eq "GenericList" -and $_.Hidden -eq $False -and $ExcludedLists -notcontains $_.Title }
            }
            catch {
                $Lists = Get-PnPList -Connection $Onprem_Sub_Connection | Where-Object { $_.BaseType -eq "GenericList" -and $_.Hidden -eq $False -and $ExcludedLists -notcontains $_.Title }
            }
          #  $Lists = Get-PnPList -Connection $Onprem_Sub_Connection | Where-Object { $_.BaseType -eq "GenericList" -and $_.Hidden -eq $False -and $ExcludedLists -notcontains $_.Title }
            $global:counter = 0
            foreach ($List in $Lists) {
                $global:counter += $List.ItemCount;
                $loopobj = New-Object System.Object
                $loopobj | Add-Member -MemberType NoteProperty -Name "Title" -Value $List.Title
                $loopobj | Add-Member -MemberType NoteProperty -Name "Source_Count" -Value $List.ItemCount
                $loopobj | Add-Member -MemberType NoteProperty -Name "Destination_Count" -Value 0
                $loopobj | Add-Member -MemberType NoteProperty -Name "Object_Type" -Value "List"
                $loopobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value ""
                $SiteItemInventory += $loopobj 
            }
    #>      
            #Get total count of Document libraries on source
            $loopobj = New-Object System.Object
            $loopobj | Add-Member -MemberType NoteProperty -Name "Title" -Value "Total Libraries"
            $loopobj | Add-Member -MemberType NoteProperty -Name "Source_Count" -Value $totalLibraries
            $loopobj | Add-Member -MemberType NoteProperty -Name "Destination_Count" -Value 0
            $loopobj | Add-Member -MemberType NoteProperty -Name "Object_Type" -Value "Library Count"
            $loopobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value ""
            $SiteItemInventory += $loopobj 
    
            #Get total count of lists on source
            $loopobj = New-Object System.Object
            $loopobj | Add-Member -MemberType NoteProperty -Name "Title" -Value "Total Lists"
            $loopobj | Add-Member -MemberType NoteProperty -Name "Source_Count" -Value $totallists
            $loopobj | Add-Member -MemberType NoteProperty -Name "Destination_Count" -Value 0
            $loopobj | Add-Member -MemberType NoteProperty -Name "Object_Type" -Value "Lists Count"
            $loopobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value ""
            $SiteItemInventory += $loopobj  
    
            #Get total count of system content type 
            <#
            $SystemContentTypes = get-pnpcontentType -Connection $Onprem_Sub_Connection | where-Object { $_.Group -notlike "_*" -and $_.Group -notlike "_Hidden*" -or $_.Group -notlike "MQ*" } | Select-Object -ExpandProperty Name
            $loopobj = New-Object System.Object
            $loopobj | Add-Member -MemberType NoteProperty -Name "Title" -Value "System Content Type Count"
            $loopobj | Add-Member -MemberType NoteProperty -Name "Source_Count" -Value $SystemContentTypes.Count
            $loopobj | Add-Member -MemberType NoteProperty -Name "Destination_Count" -Value 0
            $loopobj | Add-Member -MemberType NoteProperty -Name "Object_Type" -Value "System Content Type"
            $loopobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value ""
            $SiteItemInventory += $loopobj  
    
            $SYSCTs = $SystemContentTypes -join ";"
            $loopobj = New-Object System.Object
            $loopobj | Add-Member -MemberType NoteProperty -Name "Title" -Value "System Content Type Names"
            $loopobj | Add-Member -MemberType NoteProperty -Name "Source_Count" -Value $SYSCTs
            $loopobj | Add-Member -MemberType NoteProperty -Name "Destination_Count" -Value 0
            $loopobj | Add-Member -MemberType NoteProperty -Name "Object_Type" -Value "System Content Type"
            $loopobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value ""
            $SiteItemInventory += $loopobj
        
            # Get total number of content types on source 
            $MQCustomCTs = get-pnpcontentType -Connection $Onprem_Sub_Connection | where-Object { $_.Group -like "_*" -and $_.Group -notlike "_Hidden*" -or $_.Group -like "MQ*" } | Select-Object -ExpandProperty Name
            $loopobj = New-Object System.Object
            $loopobj | Add-Member -MemberType NoteProperty -Name "Title" -Value "Custom Content Type Count"
            $loopobj | Add-Member -MemberType NoteProperty -Name "Source_Count" -Value $MQCustomCTs.Count
            $loopobj | Add-Member -MemberType NoteProperty -Name "Destination_Count" -Value 0
            $loopobj | Add-Member -MemberType NoteProperty -Name "Object_Type" -Value "Custom Content Type"
            $loopobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value ""
            $SiteItemInventory += $loopobj  
    
            # Get list of all custom content type names
            $CUSTCTs = $MQCustomCTs -join ";"
            $loopobj = New-Object System.Object
            $loopobj | Add-Member -MemberType NoteProperty -Name "Title" -Value "Custom Content Type Names"
            $loopobj | Add-Member -MemberType NoteProperty -Name "Source_Count" -Value $CUSTCTs
            $loopobj | Add-Member -MemberType NoteProperty -Name "Destination_Count" -Value 0
            $loopobj | Add-Member -MemberType NoteProperty -Name "Object_Type" -Value "Custom Content Type"
            $loopobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value ""
            $SiteItemInventory += $loopobj
    #>
            # Get all available groups on source
            try {
                $SourceGroups = Get-PnPGroup -Connection $Onprem_Sub_Connection | Select-Object -ExpandProperty Title
                if ($SourceGroups) {
                    $loopobj = New-Object System.Object
                    $loopobj | Add-Member -MemberType NoteProperty -Name "Title" -Value "Source Permission Group Count"
                    $loopobj | Add-Member -MemberType NoteProperty -Name "Source_Count" -Value $SourceGroups.Count
                    $loopobj | Add-Member -MemberType NoteProperty -Name "Destination_Count" -Value 0
                    $loopobj | Add-Member -MemberType NoteProperty -Name "Object_Type" -Value "Source Permission Group"
                    $loopobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value ""
                    $SiteItemInventory += $loopobj
        
                    $CUSTGPs = $SourceGroups -join ";"
                    $loopobj = New-Object System.Object
                    $loopobj | Add-Member -MemberType NoteProperty -Name "Title" -Value "Source Permission Group Names"
                    $loopobj | Add-Member -MemberType NoteProperty -Name "Source_Count" -Value $CUSTGPs
                    $loopobj | Add-Member -MemberType NoteProperty -Name "Destination_Count" -Value 0
                    $loopobj | Add-Member -MemberType NoteProperty -Name "Object_Type" -Value "Source Permission Group"
                    $loopobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value ""
                    $SiteItemInventory += $loopobj
                }
            } catch {
                $logger.LogErrorMessage("Error while fetching PNP Groups")
            }
            
            try {
                # Get all available groups on source
                $SourcePermissionLevels = Get-PnPRoleDefinition -Connection $Onprem_Sub_Connection | Select-Object -ExpandProperty Name
                if ($SourcePermissionLevels) {
                    $loopobj = New-Object System.Object
                    $loopobj | Add-Member -MemberType NoteProperty -Name "Title" -Value "Source Permission Level Count"
                    $loopobj | Add-Member -MemberType NoteProperty -Name "Source_Count" -Value $SourcePermissionLevels.Count
                    $loopobj | Add-Member -MemberType NoteProperty -Name "Destination_Count" -Value 0
                    $loopobj | Add-Member -MemberType NoteProperty -Name "Object_Type" -Value "Source Permission Level"
                    $loopobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value ""
                    $SiteItemInventory += $loopobj
        
                    $CUSTGPLs = $SourcePermissionLevels -join ";"
                    $loopobj = New-Object System.Object
                    $loopobj | Add-Member -MemberType NoteProperty -Name "Title" -Value "Source Permission Level Names"
                    $loopobj | Add-Member -MemberType NoteProperty -Name "Source_Count" -Value $CUSTGPLs
                    $loopobj | Add-Member -MemberType NoteProperty -Name "Destination_Count" -Value 0
                    $loopobj | Add-Member -MemberType NoteProperty -Name "Object_Type" -Value "Source Permission Level"
                    $loopobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value ""
                    $
                }SiteItemInventory += $loopobj
            } catch {
                $logger.LogErrorMessage("Error while fetching PNP Permission")
            }
            # Create new folder and overwrite if already exist by name of site URL
           # $ExportFolderPath = Join-Path -Path $LocalLogFolder -ChildPath "$($web.ServerRelativeUrl)"
           # if (Test-Path -Path $ExportFolderPath) {
           #     Remove-Item -Path $ExportFolderPath -Recurse -Force
           # }
           # New-Item -Path $ExportFolderPath -ItemType Directory 
    
            # Export the SiteItemInventory object to a CSV file
            $subname = ""
            if($web.ServerRelativeUrl.ToString().Length - $web.ServerrelativeUrl.ToString().IndexOf($sourceroomname) - $sourceroomname.ToString().Length -gt 0) {
                $subname = "_" + $web.Serverrelativeurl.ToString().Substring($web.ServerrelativeUrl.ToString().IndexOf($sourceroomname) + $sourceroomname.ToString().Length+1)
            }
			
			if ($subname.contains("/")){
                $subname = $subname.Replace("/", "_")
            }
			
            #$ExportFolderPath = Join-Path -Path $LocalLogFolder -ChildPath "$($web.ServerRelativeUrl)"
            if (Test-Path -Path $logdir) {
               # Remove-Item -Path $logdir -Recurse -Force
            } else  {
                New-Item -Path $logdir -ItemType Directory 
            }

            $csvFilePath = Join-Path -Path $logdir -ChildPath "SiteItemInventory_$($sourceroomname)$($subname).csv"
            $SiteItemInventory | Export-Csv -Path $csvFilePath -NoTypeInformation
            $logger.LogMessage("Operation -  Premigration inventory completed.")
        }    
    }     catch {
        Write-Error $_.Exception.Message 
        $logger.LogErrorMessage($_.Exception.Message)
    }
}
<#
try {
    #Attempt to connect to the SharePoint site
    #Connect site
    if (-not (Get-Module -ListAvailable -Name PnP.PowerShell)) {
        Import-Module PnP.PowerShell
    }     
    #Read local configuration
    $scriptDirectory = Split-Path -Path $MyInvocation.MyCommand.Definition -Parent

    # Get the parent directory of the current script's directory
    $parentDirectory = Split-Path -Path $scriptDirectory -Parent

    $localconfigXmlPath = Join-Path -Path $parentDirectory -ChildPath "\Configuration\"
    $LocalXmlPath = Join-Path -Path $localconfigXmlPath -ChildPath "Local_Config.xml"
    # Check if the input folder exists
    if (-Not (Test-Path -Path $LocalXmlPath)) {
        $logger.LogErrorMessage( "The local config file does not exist at: $LocalXmlPath")
        throw "The local config file does not exist at: $LocalXmlPath"
    }
    [xml]$LocalConfigXML = get-content $LocalXmlPath
    $LocalLogFolder = $LocalConfigXML.Configuration.Parameters.LocalLogFolder
  
    Write-Progress -Activity "Started pre migration inventory on $($SiteURL)" -Status "Started" 
    $logger.LogMessage("Started pre migration inventory on $($SiteURL)")
    $TargetOnPremSubweb = Get-PnPSubWeb -IncludeRootWeb -Connection $Onprem_Connection -Recurse | Where-Object { $_.WebTemplate -ne "APP" }

    foreach ($TargetSubweb in $TargetOnPremSubweb) 
    {    
        $Onprem_Sub_Connection = Connect-SP-Onpremise-WithRetry -SiteURL $TargetSubweb.Url -Cred $Cred -maxRetries 3
        $web = Get-PnPWeb -Connection $Onprem_Sub_Connection
        $SiteItemInventory = @()
        #Get all document libraries
        $global:counter = 0
        $DocumentLibraries = Get-PnPList -Connection $Onprem_Sub_Connection | Where-Object { $_.BaseType -eq "DocumentLibrary" -and $_.Hidden -eq $False -and $ExcludedLists -notcontains $_.Title } 
        ForEach ($List in $DocumentLibraries) {
            if ($ExcludedLists -contains $List.Title) {
                $logger.LogMessage("Skipping $($List.Title) as it is in the excluded lists.")
                continue
            } 
            $FileItems = Get-PnPListItem -List $List -PageSize 500 -Fields FileLeafRef -Connection $Onprem_Sub_Connection | Where-Object { $_.FileSystemObjectType -eq "File" }
            $loopobj = New-Object System.Object
            $loopobj | Add-Member -MemberType NoteProperty -Name "Title" -Value $List.Title
            $loopobj | Add-Member -MemberType NoteProperty -Name "Source_Count" -Value $FileItems.Count
            $loopobj | Add-Member -MemberType NoteProperty -Name "Destination_Count" -Value 0
            $loopobj | Add-Member -MemberType NoteProperty -Name "Object_Type" -Value "Library"
            $SiteItemInventory += $loopobj
            
        }
        #Get total Number of Documents         
        #$loopobj | Add-Member -MemberType NoteProperty -Name "Number of Documents" -Value $global:counter

        #Get Number of Items
        try {
            $Lists = Get-PnPList -Connection $Onprem_Sub_Connection | Where-Object { $_.BaseType -eq "GenericList" -and $_.Hidden -eq $False -and $ExcludedLists -notcontains $_.Title }
        }
        catch {
            $Lists = Get-PnPList -Connection $Onprem_Sub_Connection | Where-Object { $_.BaseType -eq "GenericList" -and $_.Hidden -eq $False -and $ExcludedLists -notcontains $_.Title }
        }
      #  $Lists = Get-PnPList -Connection $Onprem_Sub_Connection | Where-Object { $_.BaseType -eq "GenericList" -and $_.Hidden -eq $False -and $ExcludedLists -notcontains $_.Title }
        $global:counter = 0
        foreach ($List in $Lists) {
            $global:counter += $List.ItemCount;
            $loopobj = New-Object System.Object
            $loopobj | Add-Member -MemberType NoteProperty -Name "Title" -Value $List.Title
            $loopobj | Add-Member -MemberType NoteProperty -Name "Source_Count" -Value $List.ItemCount
            $loopobj | Add-Member -MemberType NoteProperty -Name "Destination_Count" -Value 0
            $loopobj | Add-Member -MemberType NoteProperty -Name "Object_Type" -Value "List"
            $SiteItemInventory += $loopobj 
        }

        #Get total count of Document libraries on source
        $loopobj = New-Object System.Object
        $loopobj | Add-Member -MemberType NoteProperty -Name "Title" -Value "Total Libraries"
        $loopobj | Add-Member -MemberType NoteProperty -Name "Source_Count" -Value $DocumentLibraries.Count
        $loopobj | Add-Member -MemberType NoteProperty -Name "Destination_Count" -Value 0
        $loopobj | Add-Member -MemberType NoteProperty -Name "Object_Type" -Value "Lists Count"
        $SiteItemInventory += $loopobj 

        #Get total count of lists on source
        $loopobj = New-Object System.Object
        $loopobj | Add-Member -MemberType NoteProperty -Name "Title" -Value "Total Lists"
        $loopobj | Add-Member -MemberType NoteProperty -Name "Source_Count" -Value $Lists.Count
        $loopobj | Add-Member -MemberType NoteProperty -Name "Destination_Count" -Value 0
        $loopobj | Add-Member -MemberType NoteProperty -Name "Object_Type" -Value "Lists Count"
        #$SiteItemInventory += $loopobj  

        #Get total count of system content type 
        $SystemContentTypes = get-pnpcontentType -Connection $Onprem_Sub_Connection | where-Object { $_.Group -notlike "_*" -and $_.Group -notlike "_Hidden*" -or $_.Group -notlike "MQ*" } | Select-Object -ExpandProperty Name
        $loopobj = New-Object System.Object
        $loopobj | Add-Member -MemberType NoteProperty -Name "Title" -Value "System Content Type Count"
        $loopobj | Add-Member -MemberType NoteProperty -Name "Source_Count" -Value $SystemContentTypes.Count
        $loopobj | Add-Member -MemberType NoteProperty -Name "Destination_Count" -Value 0
        $loopobj | Add-Member -MemberType NoteProperty -Name "Object_Type" -Value "System Content Type"
        $SiteItemInventory += $loopobj  

        $SYSCTs = $SystemContentTypes -join ";"
        $loopobj = New-Object System.Object
        $loopobj | Add-Member -MemberType NoteProperty -Name "Title" -Value "System Content Type Names"
        $loopobj | Add-Member -MemberType NoteProperty -Name "Source_Count" -Value $SYSCTs
        $loopobj | Add-Member -MemberType NoteProperty -Name "Destination_Count" -Value 0
        $loopobj | Add-Member -MemberType NoteProperty -Name "Object_Type" -Value "System Content Type"
        $SiteItemInventory += $loopobj
    
        # Get total number of content types on source 
        $MQCustomCTs = get-pnpcontentType -Connection $Onprem_Sub_Connection | where-Object { $_.Group -like "_*" -and $_.Group -notlike "_Hidden*" -or $_.Group -like "MQ*" } | Select-Object -ExpandProperty Name
        $loopobj = New-Object System.Object
        $loopobj | Add-Member -MemberType NoteProperty -Name "Title" -Value "Custom Content Type Count"
        $loopobj | Add-Member -MemberType NoteProperty -Name "Source_Count" -Value $MQCustomCTs.Count
        $loopobj | Add-Member -MemberType NoteProperty -Name "Destination_Count" -Value 0
        $loopobj | Add-Member -MemberType NoteProperty -Name "Object_Type" -Value "Custom Content Type"
        $SiteItemInventory += $loopobj  

        # Get list of all custom content type names
        $CUSTCTs = $MQCustomCTs -join ";"
        $loopobj = New-Object System.Object
        $loopobj | Add-Member -MemberType NoteProperty -Name "Title" -Value "Custom Content Type Names"
        $loopobj | Add-Member -MemberType NoteProperty -Name "Source_Count" -Value $CUSTCTs
        $loopobj | Add-Member -MemberType NoteProperty -Name "Destination_Count" -Value 0
        $loopobj | Add-Member -MemberType NoteProperty -Name "Object_Type" -Value "Custom Content Type"
        $SiteItemInventory += $loopobj

        # Get all available groups on source
        $SourceGroups = Get-PnPGroup -Connection $Onprem_Sub_Connection | Select-Object -ExpandProperty Title
        if ($SourceGroups) {
            $loopobj = New-Object System.Object
            $loopobj | Add-Member -MemberType NoteProperty -Name "Title" -Value "Source Permission Group Count"
            $loopobj | Add-Member -MemberType NoteProperty -Name "Source_Count" -Value $SourceGroups.Count
            $loopobj | Add-Member -MemberType NoteProperty -Name "Destination_Count" -Value 0
            $loopobj | Add-Member -MemberType NoteProperty -Name "Object_Type" -Value "Source Permission Group"
            $SiteItemInventory += $loopobj

            $CUSTGPs = $SourceGroups -join ";"
            $loopobj = New-Object System.Object
            $loopobj | Add-Member -MemberType NoteProperty -Name "Title" -Value "Source Permission Group Names"
            $loopobj | Add-Member -MemberType NoteProperty -Name "Source_Count" -Value $CUSTGPs
            $loopobj | Add-Member -MemberType NoteProperty -Name "Destination_Count" -Value 0
            $loopobj | Add-Member -MemberType NoteProperty -Name "Object_Type" -Value "Source Permission Group"
            $SiteItemInventory += $loopobj
        }

        # Get all available groups on source
        $SourcePermissionLevels = Get-PnPRoleDefinition -Connection $Onprem_Sub_Connection | Select-Object -ExpandProperty Name
        if ($SourcePermissionLevels) {
            $loopobj = New-Object System.Object
            $loopobj | Add-Member -MemberType NoteProperty -Name "Title" -Value "Source Permission Level Count"
            $loopobj | Add-Member -MemberType NoteProperty -Name "Source_Count" -Value $SourcePermissionLevels.Count
            $loopobj | Add-Member -MemberType NoteProperty -Name "Destination_Count" -Value 0
            $loopobj | Add-Member -MemberType NoteProperty -Name "Object_Type" -Value "Source Permission Level"
            $SiteItemInventory += $loopobj

            $CUSTGPLs = $SourcePermissionLevels -join ";"
            $loopobj = New-Object System.Object
            $loopobj | Add-Member -MemberType NoteProperty -Name "Title" -Value "Source Permission Level Names"
            $loopobj | Add-Member -MemberType NoteProperty -Name "Source_Count" -Value $CUSTGPLs
            $loopobj | Add-Member -MemberType NoteProperty -Name "Destination_Count" -Value 0
            $loopobj | Add-Member -MemberType NoteProperty -Name "Object_Type" -Value "Source Permission Level"
            $SiteItemInventory += $loopobj
        }
        # Create new folder and overwrite if already exist by name of site URL
        $ExportFolderPath = Join-Path -Path $LocalLogFolder -ChildPath "$($web.ServerRelativeUrl)"
        if (Test-Path -Path $ExportFolderPath) {
            Remove-Item -Path $ExportFolderPath -Recurse -Force
        }
        New-Item -Path $ExportFolderPath -ItemType Directory 

        # Export the SiteItemInventory object to a CSV file
        $csvFilePath = Join-Path -Path $ExportFolderPath -ChildPath "SiteItemInventory.csv"
        $SiteItemInventory | Export-Csv -Path $csvFilePath -NoTypeInformation
        $logger.LogMessage("Operation -  Premigration inventory completed.")
    }
}
catch {
    Write-Error $_.Exception.Message 
    $logger.LogErrorMessage($_.Exception.Message)
} #>