<#
$clientDllPath = "C:\Migration\Sharegate_Migration_Script\SPClientDLL\Microsoft.SharePoint.Client.dll"
$runtimeDllPath = "C:\Migration\Sharegate_Migration_Script\SPClientDLL\Microsoft.SharePoint.Client.Runtime.dll"

Add-Type -Path $clientDllPath
Add-Type -Path $runtimeDllPath
#>
try {
    
    
    $jsFileUrl = $WebAppUrl + "/SiteAssets/Banner.js"

    $existingLink = Get-PnPJavaScriptLink -Name "BannerJS" -ErrorAction SilentlyContinue -Scope Site  -Connection $Onprem_Connection
    if (-not $existingLink) {
        
        Add-PnPJavaScriptLink -Name "BannerJS" -Url $jsFileUrl -Scope Site -Connection $Onprem_Connection
        Write-Host "Added"
        $logger.LogMessage("Banner.Js added to $siteUrl")
    }
    
   
}
catch {
    Write-Host  $_.Exception.Message
    $logger.LogErrorMessage($_.Exception.StackTrace)
   # Read-Host
}








