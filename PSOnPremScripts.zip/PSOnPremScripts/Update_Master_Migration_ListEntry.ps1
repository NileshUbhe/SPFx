

param (
    [Parameter(Mandatory = $true)][string]$SourceSiteURL,
    [Parameter(Mandatory = $true)][string]$ListTitle,
    [Parameter(Mandatory = $true)][string]$ItemId,
    [Parameter(Mandatory = $true)][string]$DestinationUrl,
    [Parameter(Mandatory = $true)][PSCredential]$Credential

)

try {
    $logger.LogMessage("Processing Data")
    if (-not (Get-Module -ListAvailable -Name PnP.PowerShell)) {
        Import-Module PnP.PowerShell
    }   
    $uri = New-Object System.Uri($SourceSiteURL)
    $RoorwebURL = $uri.GetLeftPart([System.UriPartial]::Authority)
    Connect-PnPOnline -Url $RoorwebURL -Credentials $Credential -TransformationOnPrem

    $list = Get-PnPList | Where-Object { $_.Title -eq $ListTitle }
    if ($list) {
        $item = Get-PnPListItem -List $list -Id $ItemId
        $item["Title"] = "Master Migration List"
        $UpdatedItemID = Set-PnPListItem -List $list -Identity $ItemId -Values @{"DestinationUrl" = $DestinationUrl }
    }
    return $UpdatedItemID
}
catch {
   Write-Error $_.Exception.Message
   $logger.LogErrorMessage($_.Exception.Message)
}