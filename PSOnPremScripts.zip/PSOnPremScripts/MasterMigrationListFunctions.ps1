enum MigrationStatus {
    Pending 
    InMigration
    Incremental
    Hypercare 
    Migrated 
    Errored 
} 

$bannerhtml = @("",
    "Your room is currently in migration. You can continue with your work without any impacts. After a period of 2 weeks, your room will be locked and finally migrated to SharePoint online. for more infromation visit https://docs.marquardt.de/x/12345",
    "Your room is currently in the final migration phase and therefore in read only mode. Please visit your room again on monday to start working effiently on SharePoint online",
    "Your room was migrated to SharePoint online. If you have any impact, let us know at https://apps.marquardt.de/sites/It_support_portal",
    "Your room was migrated successfully and therefore remain read-only. Please visit your migration room at https://marquardt.sharepoint.com/{path}",
    "")


function map-propertyKey($key, $xmlcontent) {
    $node = $xmlContent | Where-Object { $_.InnerText -eq $key }
    if ($node) {
        if ($node.Attributes.Count -gt 0) {
            $prop = $node.Attributes | Where-Object { $_.Name -eq "mapped" }
            if ($prop) {
                return $prop.value
            }
        }
    }
    return $key
}

function add-RoomOwnerProperties($siteOwners, $connection) {
    $propertyKeys = @("PrimaryOwnerDisplayName", "PrimaryOwnerMail", "SecondaryOwnerDisplayName", "SecondaryOwnerMail")

    try {
        if ($SiteOwners.Count -gt 0) {
            $siteOwner = $SiteOwners[0]
            $owner = Get-PnPUser -connection $connection | ? Email -eq $siteowner 
            if ($owner) {
                Set-PnPAdaptiveScopeProperty -Key "PrimaryOwnerDisplayName" -Value $owner.Title -Connection $connection
                Set-PnPAdaptiveScopeProperty -Key "PrimaryOwnerMail" -Value $owner.Email -Connection $connection
            }
        }
    }
    catch {
        
        $logger.LogErrorMessage( "Add Owner Property bags - $($_.Exception.Message)")
        $logger.LogErrorMessage($_.Exception.StackTrace)
    }
    try {
        if ($SiteOwners.Count -gt 1) {
            $siteOwner = $SiteOwners[1]
            $owner = Get-PnPUser -connection $connection | ? Email -eq $siteowner 
            if ($owner) {
                Set-PnPAdaptiveScopeProperty -Key "SecondaryOwnerDisplayName" -Value $owner.Title -Connection $connection
                Set-PnPAdaptiveScopeProperty -Key "SecondaryOwnerMail" -Value $owner.Email -Connection $connection
            }
        }
        
    }
    catch {
        
        $logger.LogErrorMessage( "Add Owner Property bags - $($_.Exception.Message)")
        $logger.LogErrorMessage($_.Exception.StackTrace)
    }
}

function Get-SiteOwners {
    param (
        [string]$PrimaryUser,
        [string]$SecondaryUser
    )
    try {
        $SiteOwners = @()
        $Users = @($PrimaryUser, $SecondaryUser)
        foreach ($User in $Users) {
            #$Owner = Get-PnPUser -Identity $User -Connection $Connections -Includes Email
            if ($Owner) {
                $SiteOwners += $Owner.email
            }
        }
        return $Users
    }
    catch {
        return ""
    }
   
}

function Enable-CustomScripting($url) {

    try {
        Set-PnPTenantSite -Identity $url -DenyAddAndCustomizePages:$false -Connection $spo_admin_connection
    }
    catch {
        $logger.LogErrorMessage("Enable custom scripting - $($_.Exception.Message -  $_.Exception.StackTrace)")
        Write-Host "Error enabling custom site scripting"
    }

}

function Execute-WithRetry {
    param(
        [parameter(Mandatory = $true, Position = 0)][ScriptBlock]$Command = $(throw "Parameter Command is required."),     
        [parameter(Mandatory = $false, Position = 1)][int]$RetryDelay = 10,
        [parameter(Mandatory = $false, Position = 2)][int]$MaxRetries = 5, 
        [parameter(Mandatory = $false, Position = 3)][switch]$VerboseOutput = $false
    )
    
    $currentRetry = 0
    $success = $false
    $cmd = $Command.ToString()

    do {
        try {
            $result = & $Command
            $success = $true
            if ($VerboseOutput -eq $true) {
                $Host.UI.WriteDebugLine("Successfully executed [$cmd]")
            }

            return $result
        }
        catch [System.Exception] {
            LogMessage -Message $_.Exception.ToString() -Status "Error"
            $currentRetry = $currentRetry + 1
                        
            if ($VerboseOutput -eq $true) {
                $Host.UI.WriteErrorLine("Failed to execute [$cmd]: " + $_.Exception.Message)
            }
            
            if ($currentRetry -gt $MaxRetries) {                
                throw "Could not execute [$cmd]. The error: " + $_.Exception.ToString()
            } 
            else {
                if ($VerboseOutput -eq $true) {
                    $Host.UI.WriteDebugLine("Waiting $RetryDelay second(s) before attempt #$currentRetry of [$cmd]")
                }

                # Increment the retry delay
                Start-Sleep -s $RetryDelay
            }
            $RetryDelay = $RetryDelay * $currentRetry
        }
    } while (!$success)
}

function EnableDocumentLibraryVersioning {
 
    param (
        [Parameter(Mandatory = $true)]
        [PnP.PowerShell.Commands.Base.PnPConnection]$NewConnections

    )

    $SubWebs = Get-PnPSubWeb -Connection $NewConnections -Recurse -IncludeRootWeb | Where-Object { $_.WebTemplate -ne "APP" }
    if ($SubWebs) {
        ForEach ($Web in $SubWebs) {
            $newWebConnection = Connect-SP-Online-WithRetry -DestinationUrl $Web.Url -ClientId $ClientId -CertificatePath $CertificatePath -CertificatePwd $CertificatePwd -Tenant "marquardt.com"

            $lists = get-pnplist -Connection $newWebConnection | Where-Object { $_.BaseType -eq "DocumentLibrary" -and $_.Hidden -eq $false -and $_.BaseTemplate -eq 101 }

            #$Lists = Get-PnPList -Identity "Dokumente" -Connection $newWebConnection -ErrorAction SilentlyContinue
            if ($Lists) {
                foreach ($list in $lists) {
                    #not renaming document library
                    #Set-PnPList -Identity $List.Title -Title "TeamsDocument" -Connection $newWebConnection
                    #Set-PnPList -Identity $list -EnableContentTypes $true
                    Set-PnPList -Identity $list -EnableVersioning $true -EnableMinorVersions $true -EnableContentTypes $true -Connection $newWebConnection
                    #-EnableVersioning $True -EnableMinorVersions $True
                } 
            }
            $newWebConnection = "";
        }
    }
}

function RenameDocumentLib {
 
    param (
        [Parameter(Mandatory = $true)]
        [PnP.PowerShell.Commands.Base.PnPConnection]$NewConnections
    )

    $SubWebs = Get-PnPSubWeb -Connection $NewConnections -Recurse -IncludeRootWeb | Where-Object { $_.WebTemplate -ne "APP" }
    if ($SubWebs) {
        ForEach ($Web in $SubWebs) {
            $newWebConnection = Connect-SP-Online-WithRetry -DestinationUrl $Web.Url -ClientId $ClientId -CertificatePath $CertificatePath -CertificatePwd $CertificatePwd -Tenant "marquardt.com"
            $Lists = Get-PnPList -Identity "Dokumente" -Connection $newWebConnection -ErrorAction SilentlyContinue
            if ($Lists) {
                foreach ($list in $lists) {
                    #not renaming document library
                    Set-PnPList -Identity $List.Title -Title "TeamsDocument" -Connection $newWebConnection
                } 
            }
            $newWebConnection = "";
        }
        
    }
    
}

function Push-Notification {
    param (
        [Parameter(Mandatory = $true)]
        [PnP.PowerShell.Commands.Base.PnPConnection]$Connections
    )
    $retryCount = 0
    $maxRetries = 3
    #https://learn.microsoft.com/en-us/sharepoint/dev/general-development/how-to-configure-and-use-push-notifications-in-sharepoint-apps-for-windows
    $PushNotificationFeatureId = "41E1D4BF-B1A2-47F7-AB80-D5D6CBBA3092"    
    while ($retryCount -lt $maxRetries) {
        try {
            Enable-PnPFeature -Identity $PushNotificationFeatureId -Scope Web -Connection $Connections 
            $logger.LogMessage("Push Notification Feature Has Benn Enabled")
            return
        }
        catch {
            $retryCount++
            $logger.LogMessage("Connection attempt $retryCount failed. Retrying...")
            Start-Sleep -Seconds 5
        }
    }
}
function Create-Task-List {
    param (
        [string]$ListTitle,
        [string]$ListUrl,
        [Parameter(Mandatory = $true)][PnP.PowerShell.Commands.Base.PnPConnection]$PnPConnection
    )
    try {
        $ListTemplate = [Microsoft.SharePoint.Client.ListTemplateType]::GenericList
        $Tasklist = New-PnPList -Title $ListTitle -Template $ListTemplate -Url $ListUrl -Connection $PnPConnection -ErrorAction SilentlyContinue
        $logger.LogMessage("List '$ListTitle' created successfully at '$ListUrl'")
    }
    catch {
        $logger.LogErrorMessage("Failed to create Task list '$ListTitle'. Error: $($_.Exception.Message)")
    }
}


function Create-SubRoom {
    [CmdletBinding()]

    Param
    (
        [Parameter(Mandatory = $true)][string]$SubSiteUrl,
        [Parameter(Mandatory = $true)][string]$SubRoomName,
        [Parameter(Mandatory = $true)][PnP.PowerShell.Commands.Base.PnPConnection]$PnPConnection
    )
    Process {
        $ServerRelativeUrl = Get-PnPSite -Includes RootWeb, ServerRelativeUrl -Connection $PnPConnection -ErrorAction SilentlyContinue
        $SubSiteRelativeUrl = $ServerRelativeUrl.ServerRelativeUrl + "/" + $SubSiteUrl
        #Get All Webs from the site
        $Webs = Get-PnPSubWeb -Recurse -IncludeRootWeb -Connection $PnPConnection -ErrorAction SilentlyContinue

        #Check if site exists
        $Subsite = ($Webs | Select-Object -ExpandProperty ServerRelativeUrl) -contains $SubSiteRelativeUrl
        If ($Subsite -eq $false) {
            Write-host "SubSite $($SubSiteUrl) doesn't exists!" -foregroundcolor Yellow
            New-PnPWeb -Title $SubRoomName -Url $SubSiteUrl -Locale "1031" -Template "STS#3" -Connection $PnPConnection -ErrorAction Stop
            Write-host "Sub site '$SiteTitle' Created Successfully !" -f Green
            $logger.LogMessage("Sub site '$SubSiteUrl' Created Successfully!")
            #Enable push notification for sub room
            #Push-Notification -Connections $PnPConnection
        }
        Else {
            Write-host "Sub Site $($SubSiteURL) already exists!" -foregroundcolor Green
            $logger.LogMessage("Sub Site $($SubSiteURL) already exists!")
        }
    }
}
function Get-EnvironmentUrl {
    param (
        [Parameter(Mandatory = $true)][ValidateSet("Development", "Test", "Production")][string]$Environment
    )
    switch ($Environment) {
        "Development" { return "https://ewp-dev.marquardt.de" }
        "Test" { return "https://ewp-test.marquardt.de/" }
        "Production" { return "https://ewp.marquardt.de" }
        default { throw "Invalid environment type specified." }
    }
}


function Get-PrefixEnvironment {
    param (
        [Parameter(Mandatory = $true)][ValidateSet("Development", "Test", "Production")][string]$Environment
    )
    switch ($Environment) {
        "Development" { return "dev_" }
        "Test" { return "test_" }
        "Production" { return "" }
        default { throw "Invalid environment type specified." }
    }
}

function Get-SecureStringObjectForFarm($farm, $SecuredPassword) {
    $KeyFile = Join-Path -path $env:MQConfigStore  -ChildPath $("AES_" + $Farm + ".key")
    $key = Get-Content $KeyFile
    $secpassword = $securedpassword | ConvertTo-SecureString -Key $key
    return $secpassword
}
function Connect-SP-Onpremise-WithRetry {
    param (
        [Parameter(Mandatory = $true)][string]$SiteURL,
        [Parameter(Mandatory = $true)][PSCredential]$Cred,
        [Parameter(Mandatory = $true)][int]$maxRetries = 3
    )
    $retryCount = 0
    $connected = $false
    while (-not $connected -and $retryCount -lt $maxRetries) {
        try {
            $PropertyOnpremConnection = Connect-PnPOnline -Url $SiteURL -Credentials $Cred -TransformationOnPrem -ReturnConnection
            $connected = $true
            Write-Host "Operation - Connection attempt successful - $($SiteUrl)" -ForegroundColor Green
            $logger.LogMessage( "Operation - Connection attempt successful - $($SiteUrl)")
        }
        catch {
            $retryCount++
            Write-Host "Connection attempt $retryCount failed. Retrying..." -ForegroundColor Red
            $logger.LogErrorMessage("Connection attempt $retryCount failed. Retrying...")
            Start-Sleep -Seconds 5
        }
    }

    if (-not $connected) {
        throw "Failed to establish connection after $maxRetries attempts."
    }

    return $PropertyOnpremConnection
}

function Connect-SP-Online-WithRetry {
    param (
        [Parameter(Mandatory = $true)][string]$DestinationUrl,
        [Parameter(Mandatory = $true)][string]$ClientId,
        [Parameter(Mandatory = $true)][string]$CertificatePath,
        [Parameter(Mandatory = $true)][string]$CertificatePwd,
        [Parameter(Mandatory = $true)][string]$Tenant
    )

    $retryCount = 0
    $maxRetries = 3
    $connected = $false

    while (-not $connected -and $retryCount -lt $maxRetries) {
        try {
            $connection = Connect-PnPOnline -Url $DestinationUrl -ClientId $ClientId -CertificatePath $CertificatePath -CertificatePassword (ConvertTo-SecureString -AsPlainText $CertificatePwd -Force) -Tenant $Tenant -ReturnConnection
            $connected = $true
            Write-Host "Operation - Connection attempt to destination successful - $($DestinationUrl)" -ForegroundColor Green
            $logger.LogMessage("Operation - Connection attempt to destination successful - $($DestinationUrl)")
        }
        catch {
            $retryCount++
            Write-Host "Connection attempt $retryCount failed. Retrying..." -ForegroundColor Yellow
            Start-Sleep -Seconds 5
        }
    }
    if (-not $connected) {
        throw "Failed to establish connection after $maxRetries attempts."
    }

    return $connection
}

function setMasterMigrationFields($SourceSiteURL, $ItemId, $FieldInternalName, $FieldInternalValue) {   
    $ListTitle = "Master Migration List"
    try {
        #if (-not (Get-Module -ListAvailable -Name PnP.PowerShell)) {
        #   Import-Module PnP.PowerShell
        # }   
        $list = get-pnplist -Connection $PNPMasterMigrationListConnection -Identity "Lists/$ListTitle"
        #$list = Get-PnPList -Connection $PNPMasterMigrationListConnection | Where-Object { $_.Title -eq $ListTitle }
        if ($list) {
            <# try
			{
                $MasterListItem = Get-PnPListItem -List $list -Id $ItemId -Connection $PNPMasterMigrationListConnection -ErrorAction SilentlyContinue
            }
            catch {
                $logger.LogErrorMessage("Updating master migration list - Item does not exist in master migration list with id $($ItemId)")
                $logger.LogErrorMessage($_.Exception.Message)
                $logger.LogErrorMessage($_.Exception.StackTrace)
            } 
            if ($null -ne $MasterListItem) { #>
            $UpdatedItemID = Set-PnPListItem -List $list -Identity $ItemId -Values @{
                $FieldInternalName = $FieldInternalValue
            } -Connection $PNPMasterMigrationListConnection

            if ($FieldInternalName -contains "Migration_End_Date") {
                $CurrentMigrationMasterItem = Get-PnPListItem -List $list -Id $ItemId -Fields "Migration_Start_Date" -Connection $PNPMasterMigrationListConnection -ErrorAction SilentlyContinue
                $startDate = $CurrentMigrationMasterItem.FieldValues["Migration_Start_Date"]
                if ($null -ne $startDate) {
                    $endDate = $FieldInternalValue
                    $TotalDurationinHrs = (New-TimeSpan -Start $startDate -End $endDate).TotalMinutes / 60
                    Set-PnPListItem -List $list -Identity $ItemId -Values @{"Migration_Duration" = $TotalDurationinHrs } -Connection $PNPMasterMigrationListConnection
                }
            }
            return $UpdatedItemID
            <#}
            else {
                $logger.LogMessage("Updating master migration list - Item does not exist in master migration list with id $($ItemId)")
            } #>
        }
        #Disconnect-PnPOnline
    }
    catch {
        $logger.LogErrorMessage("update master migration list - general error")
        $logger.LogErrorMessage($_.Exception.Message)
        $logger.LogErrorMessage($_.Exception.StackTrace)
    }
}
function setCommunication($SourceSiteURL, $itemid, $status) {
    $resultStatus = ""
    $ListTitle = "Master Migration List"
    try {
        Write-Progress -Activity "Processing Data"
        if (-not (Get-Module -ListAvailable -Name PnP.PowerShell)) {
            Import-Module PnP.PowerShell
        }   
        
        $list = Get-PnPList -Connection $PNPMasterMigrationListConnection | Where-Object { $_.Title -eq $ListTitle }
        if ($list) {
            #$item = Get-PnPListItem -List $list -Id $ItemId
            #$item["Title"] = "Master Migration List"
            $UpdatedItemID = Set-PnPListItem -List $list -Identity $ItemId -Values @{"Communication_x0020_step" = $status } -Connection $PNPMasterMigrationListConnection
        }
        #Disconnect-PnPOnline -Connection $PNPMasterMigrationListConnection
        return $UpdatedItemID
    }
    catch {
        $logger.LogErrorMessage("Set communication - $($_.Exception.Message)")
        Write-Error $_.Exception.Message
    }
}

function setStatus( $itemid, [MigrationStatus]$status) {
    $resultStatus = ""
    $ListTitle = "Master Migration List"
    switch ($status) {
        Pending {
            $resultStatus = "Pending"
        }
        InMigration {
            $resultStatus = "In Migration"
        }
        Hypercare {
            $resultStatus = "Hypercare"
        }
        Incremental {
            $resultStatus = "Incremental"
        }
        Migrated {
            $resultStatus = "Migrated"
        }
        Errored {
            $resultStatus = "Errored site"
        }
    }

    try {
        Write-Progress -Activity "Processing Data"
        if (-not (Get-Module -ListAvailable -Name PnP.PowerShell)) {
            Import-Module PnP.PowerShell
        }   
        
        $list = Get-PnPList -Connection $PNPMasterMigrationListConnection | Where-Object { $_.Title -eq $ListTitle }
        if ($list) {
            #$item = Get-PnPListItem -List $list -Id $ItemId
            #$item["Title"] = "Master Migration List"
            $UpdatedItemID = Set-PnPListItem -List $list -Identity $ItemId -Values @{"Migration_x0020_status" = $resultStatus } -Connection $PNPMasterMigrationListConnection
        }
        #Disconnect-PnPOnline -Connection $PNPMasterMigrationListConnection
        return $UpdatedItemID
    }
    catch {
        $logger.LogErrorMessage("Set status  -$($_.Exception.Message)")
        Write-Error $_.Exception.Message
    }
}

function setUrl($SourceSiteURL, $itemid, $url) {
    try {
        $ListTitle = "Master Migration List"
        Write-Progress -Activity "Processing Data"
        if (-not (Get-Module -ListAvailable -Name PnP.PowerShell)) {
            Import-Module PnP.PowerShell
        }   
        $uri = New-Object System.Uri($SourceSiteURL)
        $RoorwebURL = $uri.GetLeftPart([System.UriPartial]::Authority)
        $con = Connect-PnPOnline -Url $RoorwebURL -Credentials $Credential -TransformationOnPrem  -ReturnConnection

        $list = Get-PnPList -Connection $con | Where-Object { $_.Title -eq $ListTitle }
        if ($list) {
            #$item = Get-PnPListItem -List $list -Id $ItemId
            #$item["Title"] = "Master Migration List"
            $UpdatedItemID = Set-PnPListItem -List $list -Identity $ItemId -Values @{"DestinationUrl" = $DestinationUrl } -Connection $con
        }
        #  Disconnect-PnPOnline -Connection $con
        return $UpdatedItemID
    }
    catch {
        $logger.LogErrorMessage("Set Url - $($_.Exception.Message)")
        Write-Error $_.Exception.Message
    }
  
}

function revertReadOnly($SourceSiteURL) {
    try {
        $serviceUrl = "https://MQDE01SP19APP01.marquardt.de:44306/api/values/SetSiteState"

        if ($SourceSiteURL -match "/rooms/\S+") {
            $SourceSiteURL = $matches[0]
        }
        $headers = @{
            "Referer"      = "http://ewp.marquardt.de/"
            "Content-Type" = "application/json"
        }
        $body = @{
            SiteUrl = $SourceSiteURL
            State   = $false
        } | ConvertTo-Json -Depth 2
        
        $response = Invoke-RestMethod -Uri $serviceUrl -Method Post -Headers $headers -Body $body -UseDefaultCredentials -Verbose
        return $null
    }
    catch {
        return $_
    }
}

function readOnly($SourceSiteURL) {
    try {
        $serviceUrl = "https://MQDE01SP19APP01.marquardt.de:44306/api/values/SetSiteState"

        if ($SourceSiteURL -match "/rooms/\S+") {
            $SourceSiteURL = $matches[0]
        }
        $headers = @{
            "Referer"      = "http://ewp.marquardt.de/"
            "Content-Type" = "application/json"
        }
        $body = @{
            SiteUrl = $SourceSiteURL
            State   = $true
        } | ConvertTo-Json -Depth 2
        
        $response = Invoke-RestMethod -Uri $serviceUrl -Method Post -Headers $headers -Body $body -UseDefaultCredentials -Verbose
        return $null
    }
    catch {
        return $_
    }
}
function setBanner($itemid, [MigrationStatus]$status) {
    $ListTitle = "Master Migration List"
    try {
        #Write-Progress -Activity "Processing Data"
        #if (-not (Get-Module -ListAvailable -Name PnP.PowerShell)) {
        #    Import-Module PnP.PowerShell
        #}   
    
        #$RoorwebURL = $uri.GetLeftPart([System.UriPartial]::Authority)
        #$con = Connect-PnPOnline -Url $RoorwebURL -Credentials $Credential -TransformationOnPrem  -ReturnConnection

        $list = Get-PnPList -Connection $PNPMasterMigrationListConnection | Where-Object { $_.Title -eq $ListTitle }
        if ($list) {
            $message = $null
            $m = ""
            if ($status -eq 1) {
                $message = get-content "./PSOnPremScripts/BannerTemplates/Banner_InMigration.html"
            }
            if ($status -eq 2) {
                $message = get-content "./PSOnPremScripts/BannerTemplates/Banner_Incremental.html"
            }
            if ($status -eq 3) {
                $message = get-content "./PSOnPremScripts/BannerTemplates/Banner_Hypercare.html"
            }
            if ($status -eq 5) {
                $m = ""
                # nothing to display in banner
            }
            if ($null -ne $message -and $message.GetType().Name -eq "Object[]") {
                $m = $message | Out-String

                $r = [RegEx]::Matches($m, "({[a-zA-Z]+})")
                While ($r.Success) {
                    $r = $r[0]
                    $m1 = $m.Substring(0, $r.Index)
                    $m2 = $m.Substring($r.Index + $r.Length)
                    if ($r.Value -eq "{DestinationUrl}") {
                        $m = $m1 + $DestinationUrl + $m2
                    }
                    $r = [RegEx]::Matches($m, "({[a-zA-Z]+})")
                }
                    
                
                
                
            }
            # PILOT PHASE ONLY
            $UpdatedItemID = Set-PnPListItem -List $list -Identity $ItemId -Values @{"Banner_x0020_required" = $true; "Message" = $m } -Connection $PNPMasterMigrationListConnection
            #$UpdatedItemID = Set-PnPListItem -List $list -Identity $ItemId -Values @{ "Message" = $m } -Connection $PNPMasterMigrationListConnection
           

        }
        #  Disconnect-PnPOnline -Connection $con
        return $UpdatedItemID
    }
    catch {
        $logger.LogErrorMessage("SetBanner " + $_.Exception.Message)
        $logger.LogErrorMessage("SetBanner " + $_.Exception.StackTrace)
        Write-Error $_.Exception.Message
    }
}

function Backup-And-SetReadOnlyPermissions {
    param (        
        [Parameter(Mandatory = $true)]$SiteURL,
        [Parameter(Mandatory = $true)][string]$permBackupPath
    )
    $connection = Connect-SP-Onpremise-WithRetry -SiteURL $SiteURL -Cred $Cred -maxRetries 3
    $jsonPath = Join-Path -Path $permBackupPath -ChildPath "PermissionBackup.json"
    $ctx = Get-PnPContext -Connection $connection
    $web = $ctx.Web
    $ctx.Load($web)
    $ctx.Load($web.RoleAssignments)
    $ctx.ExecuteQuery()

    $backup = @()

    try {
        foreach ($ra in $web.RoleAssignments) {
            $ctx.Load($ra.Member)
            $ctx.Load($ra.RoleDefinitionBindings)
            $ctx.ExecuteQuery()
            if ($ra.Member.PrincipalType -ne "User" ) {
                $groupName = $ra.Member.Title
            }
            else {
                continue
            }
            $roles = $ra.RoleDefinitionBindings | Where-Object { $_.Name -ne "Limited Access" } | ForEach-Object { $_.Name }

            $backup += [PSCustomObject]@{
                Group = $groupName
                Roles = $roles
            }

            # Set group to Read only
            $readRole = $web.RoleDefinitions.GetByName("Read")
            $ctx.Load($readRole)
            $ctx.ExecuteQuery()

            $ra.RoleDefinitionBindings.RemoveAll()
            $ra.RoleDefinitionBindings.Add($readRole)
            $ra.Update()
            $ctx.ExecuteQuery()
        }

        # Save backup
        $backup | ConvertTo-Json | Set-Content -Path $jsonPath -Encoding UTF8
        return @{ Success = $true; Message = "Permissions backed up and all groups set to Read." }
    }
    catch {
        # Restore permissions from backup if any error occurs
        Restore-PermissionsFromBackup -ctx $ctx -permBackupPath $jsonPath | Out-Null
        return @{ Success = $false; Message = "Error occurred during permission changes. Permissions restored from backup. Error: $($_.Exception.Message)" }
    }
}

function Restore-PermissionsFromBackup {
    param (
        [Parameter(Mandatory = $true)]$SiteURL,
        [Parameter(Mandatory = $true)][string]$permBackupPath
    )
    $jsonPath = Join-Path -Path $permBackupPath -ChildPath "PermissionBackup.json" 
    $backup = Get-Content -Path $jsonPath | ConvertFrom-Json
    #sanity check for the JSON Path
    if (-not (Test-Path $jsonPath)) {
        return @{ Success = $false; Message = "Backup file not found." }
    }
    
    $connection = Connect-SP-Onpremise-WithRetry -SiteURL $SiteURL -Cred $Cred -maxRetries 3
    $ctx = Get-PnPContext -Connection $connection
    $web = $ctx.Web
    $ctx.Load($web)
    $ctx.Load($web.RoleAssignments)
    $ctx.ExecuteQuery()

    foreach ($item in $backup) {
        try {
            $group = $web.SiteGroups.GetByName($item.Group)
            $ctx.Load($group)
            $ctx.ExecuteQuery()
        }
        catch {
            $group = $web.EnsureUser($item.Group)
            $ctx.Load($group)
            $ctx.ExecuteQuery()
        }

        $ra = $web.RoleAssignments.GetByPrincipal($group)
        $ctx.Load($ra)
        $ctx.ExecuteQuery()

        $ctx.Load($ra.RoleDefinitionBindings)
        $ctx.ExecuteQuery()
        $ra.RoleDefinitionBindings.RemoveAll()
        foreach ($roleName in $item.Roles) {
            $roleDef = $web.RoleDefinitions.GetByName($roleName)
            $ctx.Load($roleDef)
            $ctx.ExecuteQuery()
            if (-not ($ra.RoleDefinitionBindings | Where-Object { $_.Name -eq $roleDef.Name })) {
                if ($roleDef.Name -ne 'Read') {
                    $ra.RoleDefinitionBindings.Add($roleDef)
                    $ra.Update()
                    $ctx.ExecuteQuery()
                }
            }
        }
    }
    $dateSuffix = Get-Date -Format "ddMMyyyy"
    $newFileName = "PermissionBackup_restored_$dateSuffix.json"
    Rename-Item -Path $jsonPath -NewName $newFileName -Force
    return @{ Success = $true; Message = "Permissions restored from backup." }
}

function SanitizeListName {
    param (
        [string]$listName
    )
    # Replace special characters with an empty string
    return ($listName -replace '[^a-zA-Z0-9 ]', '').Trim()
}

function generateUnsupportedListsCSV {
    param (        
        [Parameter(Mandatory = $true)]$SiteURL,
        [Parameter(Mandatory = $true)][string]$listCSVPath
    )
    $csvOnPremConnection = Connect-SP-Onpremise-WithRetry -SiteURL $SiteURL -Cred $Cred -maxRetries 3
    $csvPath = Join-Path -Path $listCSVPath -ChildPath "unsupportedLists.csv"
    #excluding Hidden Lists
    $allLists = Get-PnPList -includes BaseTemplate -Connection $csvOnPremConnection | Where-Object { -not $_.Hidden }
    
    #Checking for Calendar, Survey and Discussion Lists
    $unsupportedTemplates = @(102, 106, 108)
    $unsupportedLists = $allLists | Where-Object { $_.BaseTemplate -in $unsupportedTemplates }

    # Create PowerShell objects for each list
    $newRows = foreach ($list in $unsupportedLists) {
        [PSCustomObject]@{
            siteURL      = $siteURL
            listTitle    = $list.Title
            listBaseType = $list.BaseTemplate
        }
        $global:ExcludedLists += $list.Title
    }

    # Append or create the CSV
    if (Test-Path $csvPath) {
        $newRows | Export-Csv -Path $csvPath -Append -NoTypeInformation -Encoding UTF8
    } else {
        $newRows | Export-Csv -Path $csvPath -NoTypeInformation -Encoding UTF8
    }
}